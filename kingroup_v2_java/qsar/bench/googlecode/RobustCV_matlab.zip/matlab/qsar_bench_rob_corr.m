% robust standartization
% by dmitry.konovalov@jcu.edu.au, June 2008
function [res] = qsar_bench_rob_corr(x, y);
xx = qsar_bench_rob_norm(x);
yy = qsar_bench_rob_norm(y);
v = abs(xx - yy);
u = abs(xx + yy);
varV = median(v)^2;
varU = median(u)^2;
top = varU - varV;
bot = varU + varV;
if bot < 1.e-10 
    res = 1.;
else
    res = top / bot;
end
