function [minX, maxX, minY, maxY] = Figure_setMinMax(x, y, gca)
minX = min(x)
maxX = max(x)
minY = min(y)
maxY = max(y)

gapX = (maxX - minX) / 20;
gapY = (maxY - minY) / 20;

set(gca, 'XLim', [minX - gapX, maxX + gapX])
set(gca, 'YLim', [minY - gapY, maxY + gapY])
