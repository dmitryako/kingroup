% robust standartization
% by dmitry.konovalov@jcu.edu.au, June 2008
function [res] = qsar_bench_rob_corr_v2(x, y);
xx = qsar_bench_rob_norm_v2(x);
yy = qsar_bench_rob_norm_v2(y);
v = xx - yy;
u = xx + yy;
varV = qsar_bench_rob_var_v2(v);
varU = qsar_bench_rob_var_v2(u);
top = varU - varV;
bot = varU + varV;
if bot < 1.e-10 
    res = 1.;
else
    res = top / bot;
end
