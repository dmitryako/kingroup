clear all; hold on;

nX = 20; 
NUM_FIG_ROWS = 6
NUM_FIG_COLS = 4

figNum = 1
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
[z,varnames,casenames] = tblread('..\data_sets\logBB_TPSA\MedAE_OLS_Nv145.txt', 'tab');
Figure_4_MedAE_util(z, gca, nX);
ylabel('\bflogBB-TPSA\rm')
title('\bfOLS\rm');

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1)
    [z,varnames,casenames] = tblread('..\data_sets\logBB_TPSA\MedAE_CLTS_Nv145.txt', 'tab');
    Figure_4_MedAE_util(z, gca, nX);
    title('\bfCLTS\rm');
    
    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 2)
    [z,varnames,casenames] = tblread('..\data_sets\logBB_TPSA\MedAE_LTA_Nv145.txt', 'tab');
    Figure_4_MedAE_util(z, gca, nX);
    title('\bfLTA\rm');
    
    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 3)
    [z,varnames,casenames] = tblread('..\data_sets\logBB_TPSA\MedAE_LMedA_Nv145.txt', 'tab');
    Figure_4_MedAE_util(z, gca, nX);
    title('\bfLMedA\rm');
    

figNum = figNum + NUM_FIG_COLS;
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
[z,varnames,casenames] = tblread('..\data_sets\logHIA_ALOGP\MedAE_OLS_Nv63.txt', 'tab');
Figure_4_MedAE_util(z, gca, nX);
ylabel('\bflogHIA-ALOGP\rm')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1)
    [z,varnames,casenames] = tblread('..\data_sets\logHIA_ALOGP\MedAE_CLTS_Nv63.txt', 'tab');
    Figure_4_MedAE_util(z, gca, nX);
    
    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 2)
    [z,varnames,casenames] = tblread('..\data_sets\logHIA_ALOGP\MedAE_LTA_Nv63.txt', 'tab');
    Figure_4_MedAE_util(z, gca, nX);
    
    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 3)
    [z,varnames,casenames] = tblread('..\data_sets\logHIA_ALOGP\MedAE_LMedA_Nv63.txt', 'tab');
    Figure_4_MedAE_util(z, gca, nX);
    

figNum = figNum + NUM_FIG_COLS;
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
[z,varnames,casenames] = tblread('..\data_sets\logTox\MedAE_OLS_Nv15.txt', 'tab');
Figure_4_MedAE_util(z, gca, nX);
ylabel('\bflogTox-54Av\rm')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1)
    [z,varnames,casenames] = tblread('..\data_sets\logTox\MedAE_CLTS_Nv15.txt', 'tab');
    Figure_4_MedAE_util(z, gca, nX);
    
    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 2)
    [z,varnames,casenames] = tblread('..\data_sets\logTox\MedAE_LTA_Nv15.txt', 'tab');
    Figure_4_MedAE_util(z, gca, nX);
    
    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 3)
    [z,varnames,casenames] = tblread('..\data_sets\logTox\MedAE_LMedA_Nv15.txt', 'tab');
    Figure_4_MedAE_util(z, gca, nX);
    

figNum = figNum + NUM_FIG_COLS;
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
[z,varnames,casenames] = tblread('..\data_sets\RousseeuwLeroy\CYGOB1\MedAE_OLS_Nv23.txt', ',');
Figure_4_MedAE_util(z, gca, nX);
ylabel('\bfCYGOB1\rm')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1)
    [z,varnames,casenames] = tblread('..\data_sets\RousseeuwLeroy\CYGOB1\MedAE_CLTS_Nv23.txt', ',');
    Figure_4_MedAE_util(z, gca, nX);
    
    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 2)
    [z,varnames,casenames] = tblread('..\data_sets\RousseeuwLeroy\CYGOB1\MedAE_LTA_Nv23.txt', ',');
    Figure_4_MedAE_util(z, gca, nX);
    
    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 3)
    [z,varnames,casenames] = tblread('..\data_sets\RousseeuwLeroy\CYGOB1\MedAE_LMedA_Nv23.txt', ',');
    Figure_4_MedAE_util(z, gca, nX);
    

figNum = figNum + NUM_FIG_COLS;
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
[z,varnames,casenames] = tblread('..\data_sets\RousseeuwLeroy\BODY_BRAIN\MedAE_OLS_Nv14.txt', ',');
Figure_4_MedAE_util(z, gca, nX);
ylabel('\bfBODY-BRAIN\rm')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1)
    [z,varnames,casenames] = tblread('..\data_sets\RousseeuwLeroy\BODY_BRAIN\MedAE_CLTS_Nv14.txt', ',');
    Figure_4_MedAE_util(z, gca, nX);
    
    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 2)
    [z,varnames,casenames] = tblread('..\data_sets\RousseeuwLeroy\BODY_BRAIN\MedAE_LTA_Nv14.txt', ',');
    Figure_4_MedAE_util(z, gca, nX);
    
    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 3)
    [z,varnames,casenames] = tblread('..\data_sets\RousseeuwLeroy\BODY_BRAIN\MedAE_LMedA_Nv14.txt', ',');
    Figure_4_MedAE_util(z, gca, nX);
    

figNum = figNum + NUM_FIG_COLS;
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
[z,varnames,casenames] = tblread('..\data_sets\RousseeuwLeroy\GESELL\MedAE_OLS_Nv10.txt', ',');
Figure_4_MedAE_util(z, gca, nX);
ylabel('\bfGESELL\rm')
xlabel('MedAE')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1)
    [z,varnames,casenames] = tblread('..\data_sets\RousseeuwLeroy\GESELL\MedAE_CLTS_Nv10.txt', ',');
    Figure_4_MedAE_util(z, gca, nX);
    xlabel('MedAE')
    
    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 2)
    [z,varnames,casenames] = tblread('..\data_sets\RousseeuwLeroy\GESELL\MedAE_LTA_Nv10.txt', ',');
    Figure_4_MedAE_util(z, gca, nX);
    xlabel('MedAE')
    
    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 3)
    [z,varnames,casenames] = tblread('..\data_sets\RousseeuwLeroy\GESELL\MedAE_LMedA_Nv10.txt', ',');
    Figure_4_MedAE_util(z, gca, nX);
    xlabel('MedAE')
    
