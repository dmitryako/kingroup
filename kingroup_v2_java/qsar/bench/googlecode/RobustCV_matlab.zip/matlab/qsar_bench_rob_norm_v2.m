% robust standartization
% by dmitry.konovalov@jcu.edu.au, June 2008
function [normX] = qsar_bench_rob_norm_v2(x);
robVar = qsar_bench_rob_var_v2(x);
mx = median(x)
xx = x - mx;
normX = xx * (1./sqrt(robVar));
