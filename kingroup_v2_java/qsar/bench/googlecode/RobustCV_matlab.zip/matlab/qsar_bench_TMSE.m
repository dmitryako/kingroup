% The trimmed mean squared error (TMSE)
% by dmitry.konovalov@jcu.edu.au, May 2008
function [err, sortedIDX] = qsar_bench_TMSE(r, nTrim);  % r - residual errors
r2 = r.^2;
[rSort, sortedIDX] = sort(r2);      
err = sum(rSort(1:nTrim)) / nTrim;   % trimmed squared errors
   