% The trimmed mean absolute error (TMAE)
% by dmitry.konovalov@jcu.edu.au, June 2008
function [res] = qsar_bench_MAD(x);
mx = median(x)
xx = x - mx;
xx = abs(xx);
res = median(xx);
