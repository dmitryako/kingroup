% makes K elementary sets
% by dmitry.konovalov@jcu.edu.au, May 2008
function [b] = qsar_bench_makeES(Z, K);
nRow = size(Z, 1);
nCol = size(Z, 2);
n = nRow;
p = nCol;                   % the size of a "elemental set"
b = zeros(p, K);    
MAX_N_ERRORS = n;
nErr = 0;
for i = 1 : K
    order = randperm(n);     %returns a random permutation of the integers 1:n. 
    zES = Z(order(1 : p), :);  % elemental set    
    if i == K
        [y, x, bMLR, ok] = qsar_bench_OLS(Z); % include OLS of the whole set
    else
        [y, x, bMLR, ok] = qsar_bench_OLS(zES);
    end
    if ok == 0              % ignore errors
        if (nErr < MAX_N_ERRORS) % try to recover n times
            i = i - 1;
            nErr = nErr + 1;
        end
        continue;
    end    
    b(:, i) = bMLR    
end