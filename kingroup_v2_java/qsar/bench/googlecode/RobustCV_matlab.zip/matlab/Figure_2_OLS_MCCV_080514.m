% by dmitry.konovalov@jcu.edu.au, May 2008

clear all; hold on;

N = 1000;   % num of iterations
nX = 20; 

NUM_FIG_ROWS = 6
NUM_FIG_COLS = 4
nV1 = 1; % num of validation points

figNum = 1
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
[z,varnames,casenames] = tblread('..\data_sets\logBB_TPSA\KS289_logBB_Iv_Ic_TPSA.txt', 'tab')
nRow = size(z, 1); 
Figure_2_MSE_util(z, gca, N, nX, nV1);
ylabel('\bflogBB-TPSA\rm')
title('\bfn_v=1\rm')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1);
    Figure_2_MSE_util(z, gca, N, nX, nRow / 4);
    title('\bfn_v=n/4\rm')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 2);
    nRow = size(z, 1);
    Figure_2_MSE_util(z, gca, N, nX, nRow / 2);
    title('\bfn_v=n/2\rm')
    
    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 3);
    nRow = size(z, 1);
    Figure_2_MSE_util(z, gca, N, nX, nRow - nRow^0.75);
    title('\bfn_c=n^{3/4}\rm')
    
figNum = figNum + NUM_FIG_COLS;
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
[z,varnames,casenames] = tblread('..\data_sets\logHIA_ALOGP\KS127_logHIA_ALOGP.txt', 'tab')
nRow = size(z, 1); 
Figure_2_MSE_util(z, gca, N, nX, nV1);
ylabel('\bflogHIA-ALOGP\rm')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1);
    Figure_2_MSE_util(z, gca, N, nX, nRow / 4);

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 2);
    nRow = size(z, 1);
    Figure_2_MSE_util(z, gca, N, nX, nRow / 2);

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 3);
    nRow = size(z, 1);
    Figure_2_MSE_util(z, gca, N, nX, nRow - nRow^0.75);

figNum = figNum + NUM_FIG_COLS;
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
[z,varnames,casenames] = tblread('..\data_sets\logTox\KL30_LogTox_X5Av.txt', 'tab')
nRow = size(z, 1); 
Figure_2_MSE_util(z, gca, N, nX, nV1);
ylabel('\bflogTox-54Av\rm')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1);
    Figure_2_MSE_util(z, gca, N, nX, nRow / 4);

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 2);
    nRow = size(z, 1);
    Figure_2_MSE_util(z, gca, N, nX, nRow / 2);

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 3);
    nRow = size(z, 1);
    Figure_2_MSE_util(z, gca, N, nX, nRow - nRow^0.75);

figNum = figNum + NUM_FIG_COLS;
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
[z,varnames,casenames] = tblread('..\data_sets\RousseeuwLeroy\CYGOB1\page_27_CYGOB1.csv', ',')
nRow = size(z, 1); 
Figure_2_MSE_util(z, gca, N, nX, nV1);
ylabel('\bfCYGOB1\rm')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1);
    Figure_2_MSE_util(z, gca, N, nX, nRow / 4);

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 2);
    nRow = size(z, 1);
    Figure_2_MSE_util(z, gca, N, nX, nRow / 2);

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 3);
    nRow = size(z, 1);
    Figure_2_MSE_util(z, gca, N, nX, nRow - nRow^0.75);

figNum = figNum + NUM_FIG_COLS;
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
[z,varnames,casenames] = tblread('..\data_sets\RousseeuwLeroy\BODY_BRAIN\page_57_BODY_BRAIN.csv', ',')
nRow = size(z, 1); 
Figure_2_MSE_util(z, gca, N, nX, nV1);
ylabel('\bfBODY-BRAIN\rm')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1);
    Figure_2_MSE_util(z, gca, N, nX, nRow / 4);

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 2);
    nRow = size(z, 1);
    Figure_2_MSE_util(z, gca, N, nX, nRow / 2);

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 3);
    nRow = size(z, 1);
    Figure_2_MSE_util(z, gca, N, nX, nRow - nRow^0.75);

figNum = figNum + NUM_FIG_COLS;
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
[z,varnames,casenames] = tblread('..\data_sets\RousseeuwLeroy\GESELL\page_47_GESELL.csv', ',')
nRow = size(z, 1); 
Figure_2_MSE_util(z, gca, N, nX, nV1);
xlabel('MSE')
ylabel('\bfGESELL\rm')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1);
    Figure_2_MSE_util(z, gca, N, nX, nRow / 4);
    xlabel('MSE')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 2);
    nRow = size(z, 1);
    Figure_2_MSE_util(z, gca, N, nX, nRow / 2);
    xlabel('MSE')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 3);
    nRow = size(z, 1);
    Figure_2_MSE_util(z, gca, N, nX, nRow - nRow^0.75);
    xlabel('MSE')






