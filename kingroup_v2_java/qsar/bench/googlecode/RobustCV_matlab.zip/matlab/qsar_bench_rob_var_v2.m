% robust standartization
% by dmitry.konovalov@jcu.edu.au, June 2008
function [res] = qsar_bench_rob_var_v2(x);
mx = median(x)
xx = x - mx;
res = median(xx.^2);
