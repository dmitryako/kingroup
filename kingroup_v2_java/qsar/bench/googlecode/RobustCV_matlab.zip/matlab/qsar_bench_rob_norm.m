% robust standartization
% by dmitry.konovalov@jcu.edu.au, June 2008
function [normX] = qsar_bench_rob_norm(x);
mx = median(x)
xx = x - mx;
absXX = abs(xx);
madXX = median(absXX);
normX = xx * (1./madXX);
