% by dmitry.konovalov@jcu.edu.au, May 2008
function [xPoints] = qsar_bench_make_x_grid(Z, nPoints);
nRow = size(Z, 1);
nCol = size(Z, 2);
[y, x] = qsar_bench_makeYX(Z);
xPoints = zeros(nPoints, nCol)
xPoints(:, 1) = ones(nPoints, 1)
for m = 2 : nCol 
    xMin = min(x(:, m))
    xMax = max(x(:, m))
    xGrid = linspace(xMin, xMax, nPoints)
    xPoints(:, m) = xGrid'
end

