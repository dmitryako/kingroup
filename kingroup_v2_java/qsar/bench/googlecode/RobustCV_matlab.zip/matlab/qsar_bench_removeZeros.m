% by dmitry.konovalov@jcu.edu.au, May 2008
function [errC, errV] = qsar_bench_removeZeros(errC, errV);
N = size(errC, 1);
err = 1e-7;
for i = 1 : N
    if abs(errC(i)) < err  &&  abs(errV(i)) < err
    else
        validC = errC(i);
        validV = errV(i);
    end
end

for i = 1 : N
    if abs(errC(i)) < err  &&  abs(errV(i)) < err
        errC(i) = validC;
        errV(i) = validV;
    end
end
