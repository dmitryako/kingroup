% by dmitry.konovalov@jcu.edu.au, May 2008
clear all; hold on;

subplot(2, 2, 1)
fileName = '..\data_sets\RousseeuwLeroy\GESELL\page_47_GESELL.csv';
[z,varnames,casenames] = tblread(fileName, ',')

[y, x, b, ok] = qsar_bench_OLS(z);
yp = x * b
plot(x(:, 2), y, 'k.'); 
% plot(x(:, 2), y, 'k.', 'MarkerSize', 3);   
hold;

% robR = qsar_bench_rob_corr(, y);


subplot(2, 2, 2)
plot(yp, y, 'k.'); 

subplot(2, 2, 3)
yyp = qsar_bench_rob_norm(yp);
yy = qsar_bench_rob_norm(y);
plot(yyp, yy, 'k.'); 

subplot(2, 2, 4)
plot(abs(yyp - yy), abs(yyp + yy), 'k.'); 


% v = abs(xx - yy);
% u = abs(xx + yy);
% varV = median(v)^2;
% varU = median(u)^2;
% top = varU - varV;
% bot = varU + varV;
% if bot < 1.e-10 
%     res = 1.;
% else
%     res = top / bot;
% end
% 
% 
% 
% ylabel('\bfGESELL\rm')




