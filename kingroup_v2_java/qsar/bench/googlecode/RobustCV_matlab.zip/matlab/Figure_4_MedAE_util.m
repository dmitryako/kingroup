function [x, y, b] = Figure_4_MedAE_util(z, gca, nX)
z2 = z(:, 1:2); 
% [y, x, b, LTS] = qsar_bench_CLTS(z2); 
% [y, x, b, LTS] = qsar_bench_OLS(z2); 
plotX = qsar_bench_make_x_grid(z2, nX)
y = z(:, 1); 
x = z(:, 2);
plot(x, y, 'k.', 'MarkerSize', 3); 
hold;
% plotY = plotX * b; 
% plot(plotX(:, 2), plotY, 'b');

[minX, maxX, minY, maxY] = Figure_setMinMax(x, y, gca);
% figure_text_b_LB(minX, maxX, minY, maxY, b)
stepY = (maxY-minY)/5.
posX = maxX - (maxX-minX)/3.5
text(posX, maxY - 3 * stepY, num2str(mean(y), 'y=%.3g') );
text(posX, maxY - 2 * stepY, num2str(mean(x), 'x=%.3g') );

c = corrcoef(x, y);
robR = qsar_bench_rob_corr_v2(x, y);

% text(posX, maxY - 1 * stepY, num2str(c(1,2) * c(1,2),    'r^2=%.3g') );
text(posX, maxY - 1 * stepY, num2str(robR,    '\\rho=%.2g') );
text(posX, maxY - 4 * stepY, num2str(c(1,2),    'r=%.3g') );
