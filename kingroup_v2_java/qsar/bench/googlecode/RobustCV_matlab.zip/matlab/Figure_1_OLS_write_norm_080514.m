% by dmitry.konovalov@jcu.edu.au, May 2008
clear all; hold on;

N = 100;   % num of iterations

NUM_FIG_ROWS = 6
NUM_FIG_COLS = 4
figNum = 1

subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
delim = 'tab';
fileName = '..\data_sets\logBB_TPSA\KS289_logBB_Iv_Ic_TPSA.txt';
[z2,varnames,casenames] = tblread(fileName, delim);
n = size(z2, 1);     
z = zeros(n, 2);  z(: , 1) = z2(:, 1);  z(: , 2) = z2(:, 4);
[minX, maxX, b, err] = Figure_1_OLS_util(z, gca);
ylabel('\bflogBB-TPSA\rm')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1);
    z = Figure_1_make_norm_data_set(minX, maxX, b, n, err);
    varnames = int2str((1:2)');  casenames = int2str((1:n)');
    tblwrite(z, varnames, casenames, strcat(fileName, '_norm'), delim);
    Figure_1_OLS_util(z, gca);
%     title('\bfNormal errors\rm')

figNum = figNum + NUM_FIG_COLS;
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
fileName = '..\data_sets\logHIA_ALOGP\KS127_logHIA_ALOGP.txt';
[z,varnames,casenames] = tblread(fileName, delim)
[minX, maxX, b, err] = Figure_1_OLS_util(z, gca);
ylabel('\bflogHIA-ALOGP\rm')

    n = size(z, 1);     
    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1);
    z = Figure_1_make_norm_data_set(minX, maxX, b, n, err);
    varnames = int2str((1:2)');  casenames = int2str((1:n)');
    tblwrite(z, varnames, casenames, strcat(fileName, '_norm'), delim);
    Figure_1_OLS_util(z, gca);
%     ylabel('\bflogBB-TPSA\rm')

figNum = figNum + NUM_FIG_COLS;
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
fileName = '..\data_sets\logTox\KL30_LogTox_X5Av.txt';
[z,varnames,casenames] = tblread(fileName, delim)
[minX, maxX, b, err] = Figure_1_OLS_util(z, gca);
ylabel('\bflogTox-5Av\rm')

    n = size(z, 1);     
    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1);
    z = Figure_1_make_norm_data_set(minX, maxX, b, n, err);
    varnames = int2str((1:2)');  casenames = int2str((1:n)');
    tblwrite(z, varnames, casenames, strcat(fileName, '_norm'), delim);
    Figure_1_OLS_util(z, gca);
%     ylabel('\bflogBB-TPSA\rm')

figNum = figNum + NUM_FIG_COLS;
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
delim = ',';
fileName = '..\data_sets\RousseeuwLeroy\CYGOB1\page_27_CYGOB1.csv';
[z,varnames,casenames] = tblread(fileName, delim);
[minX, maxX, b, err] = Figure_1_OLS_util(z, gca);
ylabel('\bfCYGOB1\rm')

    n = size(z, 1);     
    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1);
    z = Figure_1_make_norm_data_set(minX, maxX, b, n, err);
    varnames = int2str((1:2)');  casenames = int2str((1:n)');
    tblwrite(z, varnames, casenames, strcat(fileName, '_norm'), delim);
    Figure_1_OLS_util(z, gca);
%     ylabel('\bflogBB-TPSA\rm')

figNum = figNum + NUM_FIG_COLS;
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
fileName = '..\data_sets\RousseeuwLeroy\BODY_BRAIN\page_57_BODY_BRAIN.csv';
[z,varnames,casenames] = tblread(fileName, delim)
[minX, maxX, b, err] = Figure_1_OLS_util(z, gca);
ylabel('\bfBODY-BRAIN\rm')

    n = size(z, 1);     
    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1);
    z = Figure_1_make_norm_data_set(minX, maxX, b, n, err);
    varnames = int2str((1:2)');  casenames = int2str((1:n)');
    tblwrite(z, varnames, casenames, strcat(fileName, '_norm'), delim);
    Figure_1_OLS_util(z, gca);
%     ylabel('\bflogBB-TPSA\rm')

figNum = figNum + NUM_FIG_COLS;
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
fileName = '..\data_sets\RousseeuwLeroy\GESELL\page_47_GESELL.csv';
[z,varnames,casenames] = tblread(fileName, delim)
[minX, maxX, b, err] = Figure_1_OLS_util(z, gca);
% xlabel('MSE')
ylabel('\bfGESELL\rm')

    n = size(z, 1);     
    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1);
    z = Figure_1_make_norm_data_set(minX, maxX, b, n, err);
    varnames = int2str((1:2)');  casenames = int2str((1:n)');
    tblwrite(z, varnames, casenames, strcat(fileName, '_norm'), delim);
    Figure_1_OLS_util(z, gca);

    legend('data', 'OLS', 'LTA', 'CLTS', 'Orientation', 'horizontal');

    %     ylabel('\bflogBB-TPSA\rm')



