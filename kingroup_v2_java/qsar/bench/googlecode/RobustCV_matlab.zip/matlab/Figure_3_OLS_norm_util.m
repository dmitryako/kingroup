% by dmitry.konovalov@jcu.edu.au, May 2008
function [b] = Figure_3_OLS_norm_util(gca, x, y)
nX = 20; 
z2 = zeros(size(x, 1), 2); 
z2(:, 1) = y; 
z2(:, 2) = x; 
% [y2, x2, b, LTS] = qsar_bench_CLTS(z2); 
% [y2, x2, b, LTS] = qsar_bench_OLS(z2); 
plotX = qsar_bench_make_x_grid(z2, nX);
plot(x, y, 'k.', 'MarkerSize', 3);   
% plot(x, y, 'k.'); 
hold;
% plotY = plotX * b; 
% plot(plotX(:, 2), plotY, 'b');

[minX, maxX, minY, maxY] = Figure_setMinMax(x, y, gca);
% figure_text_b_LB(minX, maxX, minY, maxY, b)
stepY = (maxY-minY)/6.
posX = maxX - (maxX-minX)/3
text(posX, maxY - 3 * stepY, num2str(mean(y), 'y=%.3g') );
text(posX, maxY - 2 * stepY, num2str(mean(x), 'x=%.3g') );
% text(posX, maxY - 1 * stepY, num2str(b(2),    'b=%.3g') );

% c = corrcoef(x, y);
robR = qsar_bench_rob_corr_v2(x, y);

% text(posX, maxY - 1 * stepY, num2str(c(1,2) * c(1,2),    'r^2=%.3g') );
text(posX, maxY - 1 * stepY, num2str(robR,    '\\rho=%.2g') );
