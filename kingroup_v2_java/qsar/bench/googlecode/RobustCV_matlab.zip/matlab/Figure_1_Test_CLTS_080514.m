clear all

hold on

nX = 20;

subplot(2,2,1)

[z,varnames,casenames] = tblread('..\data_sets\logHIA_ALOGP\KS127_logHIA_ALOGP.txt', 'tab');
[y, x, b, ok] = qsar_bench_OLS(z);
% [y, x, b, LTS] = qsar_bench_MCLTS(z);
plot(x(:, 2), y, 'k.')
hold

xMin = min(x(:, 2))
xMax = max(x(:, 2))
xGrid = linspace(xMin, xMax, nX)
x2 = zeros(nX, 2)
x2(:, 1) = ones(nX, 1)
x2(:, 2) = xGrid'
yOLS = x2 * b
plot(xGrid, yOLS, 'r')

% [y, x, b, bestErr] = qsar_bench_CLTS(z, 50, 10);
[y, x, b, bestErr] = qsar_bench_LTA(z, 100);
yNew = x2 * b
plot(xGrid, yNew, 'b')


