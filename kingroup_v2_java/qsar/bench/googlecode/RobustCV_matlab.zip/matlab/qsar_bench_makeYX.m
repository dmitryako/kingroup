% Extract Y, X from Z. 
% Y is the first column of Z.
% X is the same as Z but with ones in the first column (for MLR)
% by dmitry.konovalov@jcu.edu.au, May 2008
function [Y, X] = qsar_bench_makeYX(Z);
X = Z(:, :);  % copy
Y = X(:, 1);
X(:, 1) = ones(size(Y));

