% by dmitry.konovalov@jcu.edu.au, May 2008
function [minX, maxX, b, sampleVar] = Figure_1_OLS_util(z, gca)
nX = 20; 
n = size(z, 1);
plotX = qsar_bench_make_x_grid(z, nX)
% [b,bint,r,rint,stats] = regress(y, x)
[y, x, b, ok] = qsar_bench_OLS(z);

% robR = qsar_bench_rob_corr_v2(x * b, y);
% robR = qsar_bench_rob_corr(x * b, y);  % debugging

plot(x(:, 2), y, 'k.'); 
% plot(x(:, 2), y, 'k.', 'MarkerSize', 3);   
hold;
plotY = plotX * b; 
plot(plotX(:, 2), plotY, '--r');

kLTA = 1000;   % num of iterations for LTA
[y, x, b, err] = qsar_bench_LTA(z, kLTA);
% [y, x, b, err] = qsar_bench_OLS(z);
plotY = plotX * b; plot(plotX(:, 2), plotY, 'k-.');

nES = 100;
nC = 10;
[y, x, b, err] = qsar_bench_CLTS(z, nES, nC);
% [y, x, b, err] = qsar_bench_OLS(z);
plotY = plotX * b; plot(plotX(:, 2), plotY, 'b');

e = x * b - y;
sampleVar = sum(e.^2) / (n - 2);
robR = qsar_bench_rob_corr_v2(x * b, y);

minX = min(x(:, 2));
maxX = max(x(:, 2));
minY = min(y);
maxY = max(y);
rangeX = maxX - minX;
rangeY = maxY - minY;
gapX = rangeX / 20;
gapY = rangeY / 20;
set(gca, 'XLim', [minX - gapX, maxX + gapX])
set(gca, 'YLim', [minY - gapY, maxY + gapY])

stepY = (maxY-minY)/6.
posX = maxX - (maxX-minX)/5.
% text(posX, maxY - 3 * stepY, num2str(mean(y), 'y=%.3g') );
% text(posX, maxY - 2 * stepY, num2str(mean(x), 'x=%.3g') );
% text(posX, maxY - 1 * stepY, num2str(b(2),    'b=%.3g') );
% legend(num2str(b(2), 'b=%.3g'),'Location', 'Best')
strA = num2str(b(1), 'a = %.3g, ');
strB = num2str(b(2), 'b = %.3g, ');
strS = num2str(sqrt(sampleVar), 's = %.2g, ');
strR2 = num2str(robR, '\\rho = %.2g');
title(strcat(strA, strB, strS, strR2));
