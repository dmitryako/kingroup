% by dmitry.konovalov@jcu.edu.au, May 2008
% N - num of MCCV iterations
% nV - num of validation points
function [errC, errV] = qsar_bench_mccv(z, N, nV, opt);
nRow = size(z, 1);
nCol = size(z, 2);
n = nRow;
nC = round(n - nV); % num of calibration points

errC = zeros(N, 1);  % calibration error
errV = zeros(N, 1);  % validation errors
maxErrCount = N;
errCount = 0;
for i = 1 : N
    orderIdx = randperm(n);      %returns a random permutation of the integers 1:n. 
    [y, x, b, ok] = qsar_bench_OLS(z(orderIdx(1 : nC), :));  % 1,...,nC is calibration    
    if ok == 0   % ignore errors
        if errCount < maxErrCount
            errCount = errCount + 1;
            i = i - 1;
        end        
        continue;
    end
    e = x * b - y;  % calibration errors
    if strcmp(opt, 'MSE')  ||  strcmp(opt, 'RMSE')
        errC(i) = mean(e.^2); 
    end
    if strcmp(opt, 'MAE'), errC(i) = mean(abs(e)); end
    if strcmp(opt, 'MedAE'), errC(i) = median(abs(e)); end
    if strcmp(opt, 'corr') 
        err = corrcoef(x * b, y); 
        errC(i) = err(1, 2); 
    end
    if strcmp(opt, 'R2') 
        err = corrcoef(x * b, y); 
        errC(i) = err(1, 2).^2; 
    end

    % validation
    [y, x] = qsar_bench_makeYX(z(orderIdx(nC+1 : n), :)); % nC+1,...,n is validation
    e = x * b - y;  % validation errors
    if strcmp(opt, 'MSE')  ||  strcmp(opt, 'RMSE') 
        errV(i) = mean(e.^2); 
    end
    if strcmp(opt, 'MAE'), errV(i) = mean(abs(e)); end
    if strcmp(opt, 'MedAE'), errV(i) = median(abs(e)); end
    if strcmp(opt, 'corr') 
        err = corrcoef(x * b, y); 
        errV(i) = err(1, 2); 
    end
    if strcmp(opt, 'R2') 
        err = corrcoef(x * b, y); 
        errV(i) = err(1, 2).^2; 
    end
end

if strcmp(opt, 'RMSE') 
    errV = sqrt(errV); 
    errC = sqrt(errC); 
end

[errC, errV] = qsar_bench_removeZeros(errC, errV)
