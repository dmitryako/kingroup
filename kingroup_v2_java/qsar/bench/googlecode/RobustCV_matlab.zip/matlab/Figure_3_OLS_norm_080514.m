% by dmitry.konovalov@jcu.edu.au, May 2008
clear all; hold on;

N = 1000;   % num of iterations
nX = 20; 

NUM_FIG_ROWS = 6
NUM_FIG_COLS = 5

figNum = 1
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
[z,varnames,casenames] = tblread('..\data_sets\logBB_TPSA\KS289_logBB_Iv_Ic_TPSA.txt_norm', 'tab')
nRow = size(z, 1); 
[errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'MSE'); 
Figure_3_OLS_norm_util(gca, errC, errV);
ylabel('\bflogBB-TPSA-n\rm')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'MAE'); 
    Figure_3_OLS_norm_util(gca, errC, errV);

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 2);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'MedAE'); 
    Figure_3_OLS_norm_util(gca, errC, errV);
    
    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 3);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'RMSE'); 
    Figure_3_OLS_norm_util(gca, errC, errV);

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 4);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'R2'); 
    Figure_3_OLS_norm_util(gca, errC, errV);

figNum = figNum + NUM_FIG_COLS;
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
[z,varnames,casenames] = tblread('..\data_sets\logHIA_ALOGP\KS127_logHIA_ALOGP.txt_norm', 'tab')
nRow = size(z, 1); 
[errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'MSE'); 
Figure_3_OLS_norm_util(gca, errC, errV);
ylabel('\bflogHIA-ALOGP-n\rm')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'MAE'); 
    Figure_3_OLS_norm_util(gca, errC, errV);

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 2);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'MedAE'); 
    Figure_3_OLS_norm_util(gca, errC, errV);

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 3);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'RMSE'); 
    Figure_3_OLS_norm_util(gca, errC, errV);

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 4);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'R2'); 
    Figure_3_OLS_norm_util(gca, errC, errV);

figNum = figNum + NUM_FIG_COLS;
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
[z,varnames,casenames] = tblread('..\data_sets\logTox\KL30_LogTox_X5Av.txt_norm', 'tab')
nRow = size(z, 1); 
[errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'MSE'); 
Figure_3_OLS_norm_util(gca, errC, errV);
ylabel('\bflogTox-54Av-n\rm')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'MAE'); 
    Figure_3_OLS_norm_util(gca, errC, errV);

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 2);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'MedAE'); 
    Figure_3_OLS_norm_util(gca, errC, errV);

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 3);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'RMSE'); 
    Figure_3_OLS_norm_util(gca, errC, errV);

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 4);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'R2'); 
    Figure_3_OLS_norm_util(gca, errC, errV);

figNum = figNum + NUM_FIG_COLS;
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
[z,varnames,casenames] = tblread('..\data_sets\RousseeuwLeroy\CYGOB1\page_27_CYGOB1.csv_norm', ',')
nRow = size(z, 1); 
[errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'MSE'); 
Figure_3_OLS_norm_util(gca, errC, errV);
ylabel('\bfCYGOB1-n\rm')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'MAE'); 
    Figure_3_OLS_norm_util(gca, errC, errV);

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 2);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'MedAE'); 
    Figure_3_OLS_norm_util(gca, errC, errV);

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 3);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'RMSE'); 
    Figure_3_OLS_norm_util(gca, errC, errV);

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 4);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'R2'); 
    Figure_3_OLS_norm_util(gca, errC, errV);

figNum = figNum + NUM_FIG_COLS;
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
[z,varnames,casenames] = tblread('..\data_sets\RousseeuwLeroy\BODY_BRAIN\page_57_BODY_BRAIN.csv_norm', ',')
nRow = size(z, 1); 
[errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'MSE'); 
Figure_3_OLS_norm_util(gca, errC, errV);
ylabel('\bfBODY-BRAIN-n\rm')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'MAE'); 
    Figure_3_OLS_norm_util(gca, errC, errV);

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 2);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'MedAE'); 
    Figure_3_OLS_norm_util(gca, errC, errV);

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 3);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'RMSE'); 
    Figure_3_OLS_norm_util(gca, errC, errV);

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 4);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'R2'); 
    Figure_3_OLS_norm_util(gca, errC, errV);

figNum = figNum + NUM_FIG_COLS;
subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum)
[z,varnames,casenames] = tblread('..\data_sets\RousseeuwLeroy\GESELL\page_47_GESELL.csv_norm', ',')
nRow = size(z, 1); 
[errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'MSE'); 
Figure_3_OLS_norm_util(gca, errC, errV);
xlabel('MSE')
ylabel('\bfGESELL-n\rm')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 1);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'MAE'); 
    Figure_3_OLS_norm_util(gca, errC, errV);
    xlabel('MAE')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 2);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'MedAE'); 
    Figure_3_OLS_norm_util(gca, errC, errV);
    xlabel('MedAE')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 3);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'RMSE'); 
    Figure_3_OLS_norm_util(gca, errC, errV);
    xlabel('RMSE')

    subplot(NUM_FIG_ROWS, NUM_FIG_COLS, figNum + 4);
    [errC, errV] = qsar_bench_mccv(z, N, nRow / 2, 'R2'); 
    Figure_3_OLS_norm_util(gca, errC, errV);
    xlabel('\itR^2\rm_c')






