% The trimmed mean absolute error (TMAE)
% by dmitry.konovalov@jcu.edu.au, May 2008
function [err] = qsar_bench_TMAE(r, nTrim);  % r - residual errors
r2 = abs(r);
sortedR2 = sort(r2);      
err = sum(sortedR2(1:nTrim)) / nTrim;   % trimmed absolute errors
