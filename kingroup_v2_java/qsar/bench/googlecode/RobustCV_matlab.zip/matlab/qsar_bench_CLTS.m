% The least trimmed squares (CLTS) estimator
% Approximate algorithm from Rousseeuw&Van Driessen 
% Data Mining and Knowledge Discovery 2006, 12, 29-45.
% by dmitry.konovalov@jcu.edu.au, May 2008
% nES - num of elemental sets: normally 50-500  
% nC - number of concentration iteration steps: normally about 10
function [Y, X, bestB, bestErr] = qsar_bench_CLTS(Z, nES, nC);
[Y, X] = qsar_bench_makeYX(Z)
nRow = size(Z, 1);
nCol = size(Z, 2);
n = nRow;
p = nCol;                   % the size of the "elemental set"
% nTrim = round(n / 2);       % num of calibration points
% nTrim = round(2*n/3);       % num of calibration points
nTrim = round((n+p+1)/2);       % num of calibration points

b = qsar_bench_makeES(Z, nES) % generate K elementary sets

% Concentration
ignore = zeros(1, nES);       % "ignore" indicator 
lastErr = zeros(1, nES);      
bestErr = -1
for m = 1 : nC
    for i = 1 : nES
        if ignore(i) == 1   % ignore due to errors or convergence 
            continue
        end

        e = X * b(:, i) - Y;  % calibration errors
        [err, sortedIDX] = qsar_bench_TMSE(e, nTrim);   % trimmed mean squared error
        if bestErr < 0 || bestErr > err
            bestErr = err
            bestB = b(:, i)
        end
        if m == nC   % in the last iteration, just determine which attractor is the best (by TMSE)
            continue    
        end
        
        zTrim = Z(sortedIDX(1:nTrim), :)   % select nTrim smallest residuals        
        [yTrim, xTrim, bMLR, ok] = qsar_bench_OLS(zTrim);
        if ok == 0  
            ignore(i) = 1  % ignore this attractor due to errors
            continue
        end            
        b(:, i) = bMLR    
        if lastErr(i) == err
            ignore(i) = 1  % converged, no need to continue with this attractor
            continue
        end            
        lastErr(i) = err;
    end
end

