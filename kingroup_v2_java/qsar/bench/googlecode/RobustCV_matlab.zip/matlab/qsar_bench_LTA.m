% The least trimmed sum of absolute errors (LTA) estimator
% Approximate algorithm from Hawkins&Olive
% Computational Statistics & Data Analysis 1999, 32, 119-134. 
% by dmitry.konovalov@jcu.edu.au, May 2008
function [Y, X, bestB, bestErr] = qsar_bench_LTA(Z, K);
[Y, X] = qsar_bench_makeYX(Z)
nRow = size(Z, 1);
nCol = size(Z, 2);
n = nRow;
p = nCol;                   % the size of the "elemental set"
% K = 250         % num of elemental sets  

b = qsar_bench_makeES(Z, K) % generate K elementary sets

% select the best elementary set
% nTrim = round(2*n/3);       % num of calibration points
nTrim = round((n+p+1)/2);       % num of calibration points
bestErr = -1
for i = 1 : K
    e = X * b(:, i) - Y;  % calibration errors
    err = qsar_bench_TMAE(e, nTrim);   % trimmed mean absolute error
    if bestErr < 0 || bestErr > err
        bestErr = err
        bestB = b(:, i)
    end
end



