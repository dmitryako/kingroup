% Ordinary Least Squares (OLS), multiple linear regression (MLR)
% by dmitry.konovalov@jcu.edu.au, May 2008
function [Y, X, b, ok] = qsar_bench_OLS(Z);
nRow = size(Z, 1);
nCol = size(Z, 2);
[Y, X] = qsar_bench_makeYX(Z);
xx = X' * X;
if det(xx) == 0 % ignore errors
    b = zeros(nRow, 1);
    ok = 0;
else        
    b = inv(xx) * X' * Y;  % same as: b = x \ y    
    ok = 1;
end

