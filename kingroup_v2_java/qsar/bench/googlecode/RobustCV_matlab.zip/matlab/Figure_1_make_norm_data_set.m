% by dmitry.konovalov@jcu.edu.au, May 2008
function [z] = Figure_1_make_norm_data_set(minX, maxX, b, n, sampleVar)
z = ones(n, 2);
z(:, 2) = minX + (maxX - minX) * rand(n, 1);
y = z * b + sqrt(sampleVar) * randn(n, 1);
z(:, 1) = y;

