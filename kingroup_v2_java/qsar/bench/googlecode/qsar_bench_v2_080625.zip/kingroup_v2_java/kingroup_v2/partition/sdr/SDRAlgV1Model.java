package kingroup_v2.partition.sdr;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 29/11/2005, Time: 09:10:35
 */
public class SDRAlgV1Model
{
}
