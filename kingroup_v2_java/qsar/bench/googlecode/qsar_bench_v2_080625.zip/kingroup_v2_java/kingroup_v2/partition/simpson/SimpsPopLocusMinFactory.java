package kingroup_v2.partition.simpson;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 19/05/2005, Time: 17:31:18
 */
public class SimpsPopLocusMinFactory{
//  public SysPop makeSimpsPop(SysPop pop) {
//    SimpsPopLocusMin res = new SimpsPopLocusMin();
//    res.shallowCopyFrom(pop);
//    return res;
//  }
}