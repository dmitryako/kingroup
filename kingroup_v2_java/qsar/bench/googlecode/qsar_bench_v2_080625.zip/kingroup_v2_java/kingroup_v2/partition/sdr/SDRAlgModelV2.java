package kingroup_v2.partition.sdr;
import kingroup_v2.partition.dr.DRAlgModel;

/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 9/02/2006, Time: 13:25:52
 */
public class SDRAlgModelV2 extends DRAlgModel
{
}
