package kingroup_v2.partition.sc;
/**
 * <code>SCAlg</code>
 * <p/>
 * Date: Sep 7, 2005
 * Time: 7:44:09 AM
 *
 * @author Nigel Blair
 */
public class SCAlg {
}
