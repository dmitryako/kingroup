package kingroup_v2.kinship.like;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 21/03/2006, Time: 14:54:05
 */
public interface KinshipLikeCalculatorI
{
  public double calcLocusLog(int i, int k, int L);
}
