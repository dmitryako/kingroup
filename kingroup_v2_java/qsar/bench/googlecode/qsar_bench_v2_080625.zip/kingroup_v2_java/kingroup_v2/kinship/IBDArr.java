package kingroup_v2.kinship;
import java.util.ArrayList;

/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 4/05/2006, Time: 15:37:34
 */
public class IBDArr<T> extends ArrayList<T>
{
//  public boolean find(KinshipIBD ibd)
//  {
//    for (T v: this){
//      if (v.equals(ibd))
//        return true;
//    }
//    return false;
//  }
//  public T[] toArray() {
//    if (size() == 0)
//      return null;
//    T obj = get(0);
//    T[] res = (T[])java.lang.reflect.Array.newInstance(obj.getClass(), size());
//    for (int i = 0; i < size(); i++)
//      res[i] = get(i);
//    return res;
//  }
}
