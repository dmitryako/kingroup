package kingroup_v2.kinship;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 20/03/2006, Time: 15:48:14
 */
public interface CalculatorI
{
  public double calc(int i, int i2);
}
