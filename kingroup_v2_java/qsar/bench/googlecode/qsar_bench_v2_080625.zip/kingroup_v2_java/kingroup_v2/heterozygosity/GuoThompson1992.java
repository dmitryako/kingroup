package kingroup_v2.heterozygosity;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 29/11/2006, Time: 09:25:51
 */
public class GuoThompson1992
{
  public static final String REFERENCE = "Guo&Thompson(1992)Biometrics48p361";
}
