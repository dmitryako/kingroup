package kingroup_v2.pop.sample.builder.groups;
import kingroup_v2.pop.sample.PopBuilderModel;

/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 7/05/2006, Time: 11:35:18
 */
public class PopBuilderFullSibOptView  extends PopBuilderEqualGroupsView
{
  public PopBuilderFullSibOptView(PopBuilderModel model)
  {
    super(model);
  }
}
