package kingroup_v2.pop.sample.builder.groups;
import kingroup_v2.pop.sample.PopBuilderModel;

/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 23/11/2005, Time: 16:12:50
 */
public interface PopBuilderViewI
{
  public void loadTo(PopBuilderModel bean);
}
