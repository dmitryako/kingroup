package kingroup_v2.refs;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 13/02/2008, Time: 10:30:07
 */
public class KonovalovHeg2008_ML
{
  public static final String REFERENCE = "Konovalov&Heg(2008) MolEcologyRes 8,p256-263";
  
}
