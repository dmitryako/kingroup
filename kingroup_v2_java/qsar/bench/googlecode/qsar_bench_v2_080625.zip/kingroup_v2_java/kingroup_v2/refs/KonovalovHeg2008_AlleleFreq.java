package kingroup_v2.refs;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 13/02/2008, Time: 10:46:27
 */
public class KonovalovHeg2008_AlleleFreq
{
  public static final String REFERENCE = "Konovalov&Heg(2008) APBC2008, pp321-331";
  public static final String REFERENCE_LONG = "Konovalov&Heg(2008) Proceedings of the 6th Asia-Pacific Bioinformatics Conference, \n14-17 January, Kyoto, Japan, pp321-331";


}
