package kingroup_v2;
import java.awt.*;

/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 9/09/2005, Time: 15:19:45
 */
public class KinGroupV2Startup {
  public static final String REFERENCE = "Konovalov,Manning&Henshaw(2004)MolecularEcologyNotes4,p779";
  static private String appName = "KINGROUP";
  static private String appVersion = "v2_080620";

//  private final static ProjectLogger log = ProjectLogger.getLogger(KinGroupV2Startup.class.getName());
  private static KingroupLogger log = KingroupLogger.getInstance(appName);

  public static void main(String[] args) {
    try {
      new KinGroupV2Startup().startup(args);
    } catch(Exception e) {
      log.error("Exception", e);
    }
  }
  public void startup(String[] args)
  {
//    ProjectLogger log = ProjectLogger.getInstance();
//    System.setErr(new PrintStream(log.getOutputStream()));
//    Locale.setDefault(Locale.FRENCH);

    System.out.println(appName + " [starting ...]");
    KinGroupV2Project.makeInstance(appName, appVersion);

    Kingroup project = KinGroupV2Project.getInstance();

    KingroupFrame frame = new KingroupFrame(project);
    frame.pack();
    frame.setSize(new Dimension(300, 300));
    frame.setVisible(true);
  }
}