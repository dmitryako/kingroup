package kingroup;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * See www.kingroup.org for more details.
 * User: jc138691, Date: Jan 10, 2005, Time: 11:48:19 AM
 */
public class KinGroupError extends RuntimeException {
  public KinGroupError(String error) {
    super(error);
  }
}
