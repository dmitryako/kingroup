package kingroup.partition;
import kingroup_v2.partition.dr.DescRatioMethod;

/* Copyright (C) 2003-2004  Dr. Dmitry Konovalov.
 * This code is licensed under the GPL license (see www.gnu.org) for academic,
 * not-for-profit use or for use within other Open Source software (see www.opensource.org).
 * See www.kingroup.org for more details.
 */
public class ExhaustiveDescentMethod extends DescRatioMethod {
}