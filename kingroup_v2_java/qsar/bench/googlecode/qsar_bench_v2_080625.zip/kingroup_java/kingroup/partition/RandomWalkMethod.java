package kingroup.partition;
/* Copyright (C) 2003-2004  Dr. Dmitry Konovalov.
 * This code is licensed under the GPL license (see www.gnu.org) for academic,
 * not-for-profit use or for use within other Open Source software (see www.opensource.org).
 * See www.kingroup.org for more details.
 */
public class RandomWalkMethod {
//   extends PartitionAlg {
//    private static int count_ = 0;
//    public void init() { count_ = 0;}
//
//    public Genotype start(GenotypeGroup pool, KinshipRatioMtrxV1  pr) {
//        if (pool.size() > count_)
//            return pool.get(count_++);      // return sequence
//        return nextIdx(pool, pr);
//    }
//   public int getNumAttempts(GenotypeGroup pool) {return pool.size();}
//    public Genotype nextIdx(GenotypeGroup pool, KinshipRatioMtrxV1  pr) {
//        int idx = random_.nextInt(pool.size());
//        LOG.trace(this, "random_.nextInt(", pool.size());
//        LOG.trace(this, "                 )= ", idx);
//        return pool.get(idx);
//    }
}