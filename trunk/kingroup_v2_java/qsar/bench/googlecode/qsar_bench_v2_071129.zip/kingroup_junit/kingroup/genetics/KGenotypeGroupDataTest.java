package kingroup.genetics;

import junit.framework.TestCase;
import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * Copyright (C) 2004  Dr. Dmitry Konovalov.
 * This code is licensed under the GPL license (see www.gnu.org) for academic,
 * not-for-profit use or for use within other Open Source software (see www.opensource.org).
 * See www.kingroup.org for more details.
 * User: dmitry
 * Date: May 21, 2004, Time: 8:01:07 AM
 */
public class KGenotypeGroupDataTest extends TestCase {
   public static Test suite() { return new TestSuite(KGenotypeGroupDataTest.class); }
   public static void main(String[] args) {  junit.textui.TestRunner.run(suite()); }
   protected void setUp() {    }
}
