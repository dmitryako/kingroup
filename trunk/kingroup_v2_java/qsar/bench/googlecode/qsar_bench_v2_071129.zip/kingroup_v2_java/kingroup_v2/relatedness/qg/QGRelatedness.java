package kingroup_v2.relatedness.qg;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 7/03/2006, Time: 09:07:39
 */
public class QGRelatedness
{
  public static final String REFERENCE = "Queller & Goodnight (1989) Evolution 43 p258";
}
