package kingroup_v2.fsr;
import kingroup_v2.Kingroup;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 11/10/2005, Time: 08:53:04
 */
public class FsrAlgOptionsSDRView extends FsrAlgOptionsDRView {
  public FsrAlgOptionsSDRView(Kingroup model) {
    super(model);
  }
}
