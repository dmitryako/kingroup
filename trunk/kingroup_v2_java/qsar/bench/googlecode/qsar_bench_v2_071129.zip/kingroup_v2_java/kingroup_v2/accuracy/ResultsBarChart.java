package kingroup_v2.accuracy;

//import org.jfree.chart.axis.NumberAxis;
//import org.jfree.chart.axis.CategoryAxis;
//import org.jfree.chart.plot.CategoryPlot;
//import org.jfree.chart.plot.PlotOrientation;
//import org.jfree.chart.JFreeChart;
//import org.jfree.chart.ChartPanel;
//import org.jfree.chart.ChartFactory;
//import org.jfree.chart.renderer.category.BarRenderer;
//import org.jfree.data.category.CategoryDataset;
//import org.jfree.data.category.DefaultCategoryDataset;
import javax.swing.*;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * This code is licensed under the GPL license (see www.gnu.org) for academic,
 * not-for-profit use or for use within other Open Source software (see www.opensource.org).
 * See www.kingroup.org for more details.
 * User: jc138691
 * Date: Sep 29, 2004, Time: 5:01:08 PM
 */
public class ResultsBarChart extends JPanel {
  public ResultsBarChart() {
//      final CategoryDataset dataset = createDataset();
//      final JFreeChart chart = createChart(dataset);
//      final ChartPanel chartPanel = new ChartPanel(chart);
//      chartPanel.setPreferredSize(new Dimension(200, 200));
//      addLine(chartPanel);
  }
//   private CategoryDataset createDataset() {
//
//       // row keys...
//       final String series1 = "First";
//
//       // column keys...
//       final String category1 = "1";
//       final String category2 = "2";
//       final String category3 = "3";
//       final String category4 = "4";
//       final String category5 = "5";
//
//       // create the dataset...
//       final DefaultCategoryDataset dataset = new DefaultCategoryDataset();
//
//       dataset.addValue(1.0, series1, category1);
//       dataset.addValue(4.0, series1, category2);
//       dataset.addValue(3.0, series1, category3);
//       dataset.addValue(5.0, series1, category4);
//       dataset.addValue(5.0, series1, category5);
//
//       return dataset;
//
//   }
//   private JFreeChart createChart(final CategoryDataset dataset) {
//
//       // create the chart...
//       final JFreeChart chart = ChartFactory.createBarChart(
//           "Bar Chart Demo",         // chart title
//           "Category",               // domain axis label
//           "Value",                  // range axis label
//           dataset,                  // data
//           PlotOrientation.VERTICAL, // orientation
//           true,                     // include legend
//           true,                     // tooltips?
//           false                     // URLs?
//       );
//
//       // NOW DO SOME OPTIONAL CUSTOMISATION OF THE CHART...
//
//       // set the background color for the chart...
//       chart.setBackgroundPaint(Color.white);
//
//       // get a reference to the plot for further customisation...
//       final CategoryPlot plot = chart.getCategoryPlot();
//       plot.setBackgroundPaint(Color.lightGray);
//       plot.setDomainGridlinePaint(Color.white);
//       plot.setRangeGridlinePaint(Color.white);
//
//       // set the range axis to display integers only...
//       final NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
//       rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
//
//       // disable bar outlines...
//       final BarRenderer renderer = (BarRenderer) plot.getRenderer();
//       renderer.setDrawBarOutline(false);
//
//       final CategoryAxis domainAxis = plot.getDomainAxis();
////       domainAxis.setCategoryLabelPositions(
////           CategoryLabelPositions.createUpRotationLabelPositions(Math.PI / 6.0)
////       );
//
//       return chart;
//
//   }
}
