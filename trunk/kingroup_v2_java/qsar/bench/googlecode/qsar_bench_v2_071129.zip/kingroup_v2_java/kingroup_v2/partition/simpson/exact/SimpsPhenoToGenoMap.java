package kingroup_v2.partition.simpson.exact;
import java.util.BitSet;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 7/07/2005, Time: 18:44:50
 */
public class SimpsPhenoToGenoMap extends BitSet {
}
