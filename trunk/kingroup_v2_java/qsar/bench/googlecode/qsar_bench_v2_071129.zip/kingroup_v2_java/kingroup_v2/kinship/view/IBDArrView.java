package kingroup_v2.kinship.view;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 4/05/2006, Time: 15:30:49
 */
public class IBDArrView<M>
//  extends GridBagView
//  implements JTableViewI
{
  // todo: how to make a generic Kinship/ThompsonIBDArrView?
}
