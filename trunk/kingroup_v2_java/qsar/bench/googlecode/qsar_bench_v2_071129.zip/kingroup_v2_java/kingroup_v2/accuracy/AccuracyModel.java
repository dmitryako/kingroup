package kingroup_v2.accuracy;
import kingroup.papers.butler2004.ButlerPopBuilderModel;
import kingroup.partition.PartitionModel;
import kingroup.project.KinGroupProjectModel;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * This code is licensed under the GPL license (see www.gnu.org) for academic,
 * not-for-profit use or for use within other Open Source software (see www.opensource.org).
 * See www.kingroup.org for more details.
 * User: jc138691
 * Date: Sep 27, 2004, Time: 1:19:02 PM
 */
final public class AccuracyModel extends PartitionModel {
  final private ButlerPopBuilderModel butler_;
  private AccuracySimModel accuracySimModel_;
  public AccuracyModel(KinGroupProjectModel model) {
    super(model);
    butler_ = model.getButlerPopModel();
//      accuracySimModel_ = model.getAccuracySimModel();
  }
  final public ButlerPopBuilderModel getButlerPopModel() {
    return butler_;
  }
  final public AccuracySimModel getAccuracySimModel() {
    return accuracySimModel_;
  }
  final public void loadDefaults() {
    super.loadDefaults();
    if (butler_ != null)
      butler_.loadDefaults();
    if (accuracySimModel_ != null)
      accuracySimModel_.loadDefaults();
  }
}
