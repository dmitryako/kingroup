package kingroup_v2.accuracy;
import kingroup.model.RunSimModel;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * This code is licensed under the GPL license (see www.gnu.org) for academic,
 * not-for-profit use or for use within other Open Source software (see www.opensource.org).
 * See www.kingroup.org for more details.
 * User: jc138691
 * Date: Sep 29, 2004, Time: 3:35:12 PM
 */
final public class AccuracySimModel extends RunSimModel {
  private boolean displayPartitionTable;
  public void loadDefaults() {
    setNumRuns(10);
  }
  public boolean getDisplayPartitionTable() {
    return displayPartitionTable;
  }
  public void setDisplayPartitionTable(boolean displayPartitionTable) {
    this.displayPartitionTable = displayPartitionTable;
  }
}
