package kingroup_v2.kinship.view;
import kingroup_v2.kinship.like.view.KinshipRatioSimTableView;
import kingroup_v2.view.KingroupViewI;

/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 19/03/2006, Time: 11:45:18
 */
public interface KinshipRatioOptViewI extends  KingroupViewI
{
  public void setRatioSimTableView(KinshipRatioSimTableView view);
}
