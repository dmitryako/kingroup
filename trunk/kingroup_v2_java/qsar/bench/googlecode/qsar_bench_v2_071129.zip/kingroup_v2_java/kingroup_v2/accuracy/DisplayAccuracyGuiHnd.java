package kingroup_v2.accuracy;
import kingroup.gui.MainGui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * This code is licensed under the GPL license (see www.gnu.org) for academic,
 * not-for-profit use or for use within other Open Source software (see www.opensource.org).
 * See www.kingroup.org for more details.
 * User: jc138691
 * Date: Sep 27, 2004, Time: 9:16:52 AM
 */
public class DisplayAccuracyGuiHnd implements ActionListener {
  public void actionPerformed(ActionEvent event) {
    MainGui view = MainGui.getInstance();
//      AccuracyModel model = KinGroupProjectV1.getInstance().getKinGroupAccuracyModel();
//      AccuracyGui gui = new AccuracyGui(model);
//      view.addKinGroupAccuracyGui(gui);
  }
}
