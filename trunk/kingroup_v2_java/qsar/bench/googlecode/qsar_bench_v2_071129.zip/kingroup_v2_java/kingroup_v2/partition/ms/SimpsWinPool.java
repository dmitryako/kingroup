package kingroup_v2.partition.ms;
import kingroup.partition.PartitionV2Pool;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 18/05/2005, Time: 16:09:21
 */
public class SimpsWinPool extends PartitionV2Pool {
  public SimpsWinPool(int size) {
    super(size);
  }
}
