package kingroup_v2.kinship;
import kingroup_v2.pop.allele.freq.SysAlleleFreq;
import kingroup_v2.pop.allele.freq.SysAlleleFreqFactory;
import kingroup_v2.pop.sample.sys.SysPop;
import kingroup_v2.relatedness.PairwiseRMtrx;

/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 13/03/2006, Time: 08:40:14
 */
public class KinshipRMtrxBiasGroupArr extends PairwiseRMtrx
{
  final private SysPop[] groups;
  public KinshipRMtrxBiasGroupArr(SysPop[] groups, SysPop pop)
  {
    super(pop);
    this.groups = groups;
  }

  public void calc() {
    SysAlleleFreq saved = pop.getFreq();

    SysAlleleFreq freq = SysAlleleFreqFactory.makeFrom(pop, false);
    for (int g = 0; g < groups.length; g++) {
      SysPop group = groups[g];
      for (int g2 = 0; g2 <= g; g2++) {
        SysPop group2 = groups[g2];
        SysAlleleFreq tmpFreq = SysAlleleFreqFactory.makeDeepCopy(freq);
        SysAlleleFreqFactory.subtract(group, tmpFreq);
        if (g != g2)
          SysAlleleFreqFactory.subtract(group2, tmpFreq);
        tmpFreq.normalize(1., false);
        pop.setFreq(tmpFreq);
        for (int i = 0; i < group.size(); i++) {
          int popIdx = group.getIdIdx(i);
          for (int i2 = 0; i2 < group2.size(); i2++) {
            if (g == g2 && i >= i2) // calc lower triangle for the same group
              continue;
            int popIdx2 = group2.getIdIdx(i2);
            double sum = estimator.calc(popIdx, popIdx2);
            set(popIdx, popIdx2, sum);
          }
        }
      }
    }
    pop.setFreq(saved);
  }
}
