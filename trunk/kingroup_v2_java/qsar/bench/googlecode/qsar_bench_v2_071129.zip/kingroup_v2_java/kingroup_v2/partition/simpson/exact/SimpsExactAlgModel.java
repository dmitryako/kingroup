package kingroup_v2.partition.simpson.exact;
import kingroup_v2.partition.ms2.MS2AlgModel;

/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 29/11/2005, Time: 08:24:04
 */
public class SimpsExactAlgModel extends MS2AlgModel
{
}
