package kingroup_v2.partition.simpson;
import kingroup.KinGroupError;
import kingroup_v2.pop.sample.sys.SysPop;

import javax.utilx.bitset.CompBitSet;
import javax.utilx.pair.IntPairSymmKey;
import java.util.TreeSet;

/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 28/11/2005, Time: 17:06:02
 */
public abstract class SibshipAlg
{
  public static final byte NOT_SET = -1;
  public abstract boolean isSibGroupSLOW(SysPop pop, CompBitSet group);

  protected void loadAlleleAndLocusSetsSLOW(SysPop pop, TreeSet locusSet, TreeSet alleleSet
    , CompBitSet group, byte locusIdx) {
    short idx = -1;
    for (; ;) {
      idx = (short) group.nextSetBit(idx + 1); // for all members of this group
      if (idx == -1)
        break;
      byte pi = pop.getAllele(idx, locusIdx, pop.PAT); // idx of paternal getAllele
      byte mi = pop.getAllele(idx, locusIdx, pop.MAT); // idx of maternal getAllele
//         LOG.report(this, "group( "+new IntPairSymmKey(pi, mi));
      assert(pi != NOT_SET && mi != NOT_SET);
      if (pi == NOT_SET || mi == NOT_SET)
        throw new KinGroupError("pi == NOT_SET  ||  mi == NOT_SET");
      if (alleleSet.add(new Byte(pi))) {
//            LOG.report(this, "alleleSet.addLine( "+pi);
      }
      if (alleleSet.add(new Byte(mi))) {
//            LOG.report(this, "alleleSet.addLine( "+mi);
      }
      if (locusSet.add(new IntPairSymmKey(pi, mi))) {
//            LOG.report(this, "locusSet.addLine( "+new IntPairSymmKey(pi, mi));
      }
    }
  }
}
