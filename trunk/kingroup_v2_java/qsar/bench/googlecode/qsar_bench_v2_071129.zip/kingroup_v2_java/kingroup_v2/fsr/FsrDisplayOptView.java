package kingroup_v2.fsr;
import kingroup_v2.Kingroup;
import pattern.ucm.UCController;
import pattern.ucm.UCNewThreadActionListener;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swingx.panelx.GridBagView;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 8/10/2005, Time: 17:54:14
 */
public class FsrDisplayOptView extends GridBagView {
  private JRadioButton user;
  private JRadioButton sys;
  private JCheckBox byGroup;
  public FsrDisplayOptView(Kingroup model) {
    init();
    loadFrom(model);
    assemble();
  }
  private void init() {
    Border border = BorderFactory.createEtchedBorder();
    Border titled = BorderFactory.createTitledBorder(border, "Display");
    setBorder(titled);
    user = new JRadioButton("User");
    sys = new JRadioButton("System");
    ButtonGroup bGroup = new ButtonGroup();
    bGroup.add(user);
    bGroup.add(sys);

    byGroup = new JCheckBox("sort");
    byGroup.setToolTipText("sort by group");
  }
  public void loadTo(Kingroup model) {
    model.setFsrUserView(user.isSelected());
    model.setFsrSortByGroup(byGroup.isSelected());
  }
  protected void loadFrom(Kingroup model) {
    user.setSelected(model.getFsrUserView());
    sys.setSelected(!model.getFsrUserView());
    byGroup.setSelected(model.getFsrSortByGroup());
  }
  protected void assemble() {
    endRow(byGroup);
    endRow(user);
    endRow(sys);
  }
  public void onDisplayViewChange(UCController uc) {
    user.addActionListener(new UCNewThreadActionListener(uc));
    sys.addActionListener(new UCNewThreadActionListener(uc));
  }
  public void onSortByGroupChange(UCController uc) {
    byGroup.addActionListener(new UCNewThreadActionListener(uc));
  }
}
