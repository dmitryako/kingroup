package kingroup_v2.kinship.view;

import javax.swing.*;

/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 26/01/2006, Time: 16:39:43
 */
public class KinshipRMainView extends JPanel {
}
