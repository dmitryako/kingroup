package kingroup_v2.pop.allele.freq;

import kingroup_v2.Kingroup;
import kingroup_v2.view.KingroupViewI;
import tsvlib.project.ProjectLogger;

import javax.swingx.panelx.GridBagView;
import java.awt.*;

/**
 * Created by IntelliJ IDEA.
 * User: ESHFreeUser
 * Date: 7/06/2006
 * Time: 13:26:41
 * To change this template use File | Settings | File Templates.
 */
public class PopFreqOptView
extends GridBagView
implements KingroupViewI {
  private static ProjectLogger log = ProjectLogger.getLogger(PopFreqOptView.class.getName());

  public PopFreqOptView(Kingroup model) {
    init();
    loadFrom(model);
    assemble();
  }

  private void assemble()
  {
//      startRow(new JLabel(AlleleAnalysisByRow.getValName(i)));
//      endRow(new JLabel(AlleleAnalysisByRow.getValTip(i)));
  }

  public void loadFrom(Kingroup model)
  {
  }

  public Dimension getMinimumSize() {
//    log.info("curr min size = " + super.getMinimumSize());
//    log.info("curr pref size = " + super.getPreferredSize());
    int EXTRA_SIZE = 10;
    Dimension d = getPreferredSize();
    return new Dimension(d.width + EXTRA_SIZE, d.height + EXTRA_SIZE);
  }
  public void init() {
    //setBorder(BorderFactory.createLoweredBevelBorder());
    getStartRow().anchor = GridBagConstraints.NORTHWEST;
  }

  public void loadTo(Kingroup model)
  {
  }
}

