package kingroup_v2.identix;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 12/04/2006, Time: 12:27:09
 */
public class Identix
{
  public static final String REFERENCE = "Belkhir et al (2002) Molecular Ecology Notes 2 p611";
}
