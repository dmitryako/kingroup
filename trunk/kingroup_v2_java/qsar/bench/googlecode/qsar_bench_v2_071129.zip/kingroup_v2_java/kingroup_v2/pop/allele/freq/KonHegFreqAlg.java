package kingroup_v2.pop.allele.freq;
import kingroup_v2.cervus.AlleleAnalysisFactory;
import kingroup_v2.pop.sample.sys.SysPop;
import kingroup_v2.pop.sample.sys.SysPopFactory;
import kingroup_v2.relatedness.RMtrxOutbredKH;
import tsvlib.project.ProjectLogger;

import javax.mathx.MathX;
import javax.swingx.ProgressMonitorX;
import javax.utilx.RandomSeed;
import javax.utilx.arrays.vec.Vec;
import java.util.BitSet;

/**
 * Created by: jc1386591
 * Date: 14/07/2006. Time: 14:12:23
 */
public class KonHegFreqAlg {
  public static final String REFERENCE = "Konovalov & Heg (2008)\n ESTIMATION OF POPULATION ALLELE FREQUENCIES FROM SAMPLES CONTAINING MULTIPLE GENERATIONS, APBC2008, in press";
  private ProgressMonitorX progress;
  private double EPS = 1e-10;
  private int GROUP_IDX = 1;
  private static final double K_B = -1. / Math.log(0.5);

  protected final static ProjectLogger log = ProjectLogger.getAnonymousLogger();
  private static final double MIN_COST = 1e-7;

  public SysAlleleFreq calc(SysPop givenPop)
  {
    int n = givenPop.size();
    log.debug("\ngivenPop=\n", givenPop);
    SysAlleleFreq givenAlleleCount = SysAlleleFreqFactory.makeFrom(givenPop, false);
    log.debug("\ngivenAlleleCount=\n", givenAlleleCount);

    SysPop pop = SysPopFactory.makeDeepCopy(givenPop);

//    int MAX_COUNT = 50000;
    int MAX_COUNT = 100 * n;
    BitSet currC = new BitSet();

    // STEP 1
    currC.set(0, n);   // Include all
    double currZ = calcCost(currC, pop);      log.debug("currZ=", currZ);
    double bestZ = currZ;
    BitSet bestC = currC;

//    int TERMINATE_COUNT = 100;  //todo
    for (int i = 0; i < MAX_COUNT; i++) {
      if (progress != null
        && progress.isCanceled(i, 0, MAX_COUNT)) {
        break;
      }

      // STEP 2.
      BitSet newC = makeNewC(currC, n);       log.debug("newC = ", newC);
      if (!valid(newC, pop, givenAlleleCount))
        continue;
      double newZ = calcCost(newC, pop);      log.debug("newZ = ", newZ);

      // STEP 3.
      if (newZ < bestZ) {
        bestZ = newZ;                log.debug("\nbestZ = ", bestZ);
        bestC = newC;                log.debug("\nbestC = ", bestC);
        if (bestZ < MIN_COST)  {
//          log.info("bestZ < MIN_COST, bestC=\n", bestC);
          log.info("MIN_COST > bestZ=" +(float)bestZ);
          break;
        }
      }
      if (newZ <= currZ  ||  acceptNew(newZ, currZ, i, MAX_COUNT)) {
        currC = newC;
      }
    }
    if (progress != null)
      progress.close();
    SysPopFactory.setGroupIds(GROUP_IDX, bestC, pop); // need ids for viewing
    SysPop bestPop = SysPopFactory.makeGroupFrom(GROUP_IDX, pop);          log.info("bestPop=\n", bestC);
    SysAlleleFreq bestFreq = SysAlleleFreqFactory.makeFrom(bestPop, true); log.debug("bestFreq=\n", bestFreq);
    return bestFreq;
  }

  private boolean valid(BitSet newC, SysPop pop, SysAlleleFreq givenAlleleCount)
  {
    SysPopFactory.setGroupIds(GROUP_IDX, newC, pop); // need ids for viewing
    SysPop newPop = SysPopFactory.makeGroupFrom(GROUP_IDX, pop);          log.debug("\nnewPop=\n", newPop);
    SysAlleleFreq newFreq = SysAlleleFreqFactory.makeFrom(newPop, false);
    boolean ok = SysAlleleFreqFactory.hasAllAlleles(newFreq, givenAlleleCount);   //Check that all alleles are present
    if (!ok) {
      log.debug("\nnewFreq MISSING ALLELE=\n", newFreq);
      log.debug("\ngivenAlleleCount=\n", givenAlleleCount);
    }
    return ok;
  }

  private BitSet makeNewC(BitSet currC, int n)
  {
    RandomSeed rand = RandomSeed.getInstance();
    BitSet newC = new BitSet();
    newC.set(0, n, false);
    newC.or(currC);
    newC.flip(rand.nextInt(n));    log.debug("\nnewC = ", newC);
    return newC;
  }

  private double calcCost(BitSet set, SysPop pop) {               log.debug("calcCost(set = ", set);
    SysPopFactory.setGroupIds(GROUP_IDX, set, pop);               log.debug("pop = \n", pop);
    SysPop setPop = SysPopFactory.makeGroupFrom(GROUP_IDX, pop);  log.debug("setPop = \n", setPop);
    RMtrxOutbredKH R = new RMtrxOutbredKH(setPop);
    R.calc();
    double sum = 0;
    int n = setPop.size();
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < i; j++) {
        sum += Math.abs(R.get(i, j));
//        sum += R.get(i, j);
      }
    }                                                                log.debug("sum =", sum);
    double h = AlleleAnalysisFactory.calcObservHeterozAvr(setPop);  log.debug("h=", h);
    sum *= h;                                                        log.debug("sum *= h =", sum);
    sum /= ((2.*n - 1.) * n);                                        log.debug("sum /=", sum);
//    return sum;
    return Math.abs(sum);
  }

  private boolean acceptNew(double newL, double currL, int i, int maxCount)
  {
    double diffL = (newL - currL) / newL;       log.debug("diffL=", diffL);
    double T = (double)(maxCount - i) / maxCount;       log.debug("T=", T);
    double pr = Math.exp(- diffL / (K_B * T));  log.debug("Pr=", pr);
    return RandomSeed.getInstance().makeRandomEvent(pr);
  }

  public SysAlleleFreq calcOLD(SysPop sysPop)
  {
    int n = sysPop.size();
    log.info("\nsysPop=\n" + sysPop);
    SysAlleleFreq savedFreq = sysPop.getFreq();
    log.info("\nsavedFreq=\n" + savedFreq);

    //double[] trueHet = AlleleAnalysisFactory.calcTrueHeteroz(sysPop);
    //log.info("\ntrueHet=" + DoubleArr.toString(trueHet));
    //log.info("\ntrueHet Avr=" + (float)DoubleArr.avr(trueHet));

    double[] obsHet = AlleleAnalysisFactory.calcObservHeteroz(sysPop);
    log.info("\nobsHet=" + Vec.toString(obsHet));
    log.info("\nobsHet Avr=" + (float)Vec.avr(obsHet));
    log.info("\nobsHet Avr2=" + (float)AlleleAnalysisFactory.calcObservHeterozAvr(sysPop));

    double[] currW = Vec.makeArray(1./n, n);
    SysAlleleFreq currFreq = SysAlleleFreqFactory.makeFrom(currW, sysPop);
    sysPop.setFreq(currFreq);
    double[] currHet = AlleleAnalysisFactory.calcTrueHeteroz(sysPop.getFreq());
    log.info("\ncurrHet=" + Vec.toString(currHet));
    log.info("\ncurrHet Avr=" + (float)Vec.avr(currHet));

    int ITERS = 100;
    double[] prec = {0.5, 2, 0.80, 1.25, 0.9, 1.1, 0.95, 1.05}; // precision
    BitSet usePrec = new BitSet();
    usePrec.set(0, prec.length);
    double obsHetAvr = Vec.avr(obsHet);
    double currHetAvr = Vec.avr(currHet);
    double currDist = MathX.pow(obsHetAvr - currHetAvr, 2);
    //double currDist = DoubleArr.dist2(obsHet, currHet);

    for (int m = 0; m <= ITERS; m++) {
      if (progress != null
        && progress.isCanceled(m, 0, ITERS)) {
        currFreq = null;
        break;
      }
      if (m == ITERS) {
        currFreq = null;
        break;
      }
      for (int s = 0; s < prec.length; s++) {
        if (!usePrec.get(s))
          continue;
        usePrec.set(s, false);  // ASSUME CANNOT GET BETTER AT THIS PRECISION
        for (int i = 0; i < n; i++) {
          double[] newW = Vec.copy(currW);
          newW[i] *= prec[s];
          Vec.norm(newW, 1.);
          SysAlleleFreq newFreq = SysAlleleFreqFactory.makeFrom(newW, sysPop);
          sysPop.setFreq(newFreq);
          double[] newHet = AlleleAnalysisFactory.calcTrueHeteroz(sysPop.getFreq());
          double newHetAvr = Vec.avr(newHet);
          double newDist = MathX.pow(obsHetAvr - newHetAvr, 2);
          //double newDist = DoubleArr.dist2(obsHet, newHet);

          if (newDist > currDist)
            continue; // ignore
          if (Math.abs(currDist - newDist) > EPS)
            usePrec.set(s, true);  // THIS PRECISION IS STILL OK

          /*
          log.info("\ncurrDist =" + (float)currDist
            + "\nnewDist =" + (float)newDist
            + "\nobsHet =" + DoubleArr.toString(obsHet)
            //+ "\nHet =" + DoubleArr.toString(newHet)
            + "\nnewHet =" + DoubleArr.toString(newHet)
            + "\nnewW =" + DoubleArr.toString(newW)
          );*/

          //log.info("\nnewHet Avr=" + (float)DoubleArr.avr(newHet)
          //+ "\nobsHet Avr=" + (float)DoubleArr.avr(obsHet)
          //);

          //log.info("\nnewFreq=\n" + newFreq);
          //log.info("\nusePrec=\n" + usePrec);
          currHet = newHet;
          currFreq = newFreq;
          currW = newW;  // remember better weights
          currDist = newDist;
        }
      }
      if (usePrec.isEmpty())
        break;
    }
    if (progress != null)
      progress.close();
    sysPop.setFreq(savedFreq);
    return currFreq;
  }
  public void setProgress(ProgressMonitorX progress) {
    this.progress = progress;
  }
}
