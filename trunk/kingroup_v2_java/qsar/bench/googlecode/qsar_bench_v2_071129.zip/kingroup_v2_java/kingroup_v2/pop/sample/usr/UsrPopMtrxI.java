package kingroup_v2.pop.sample.usr;
import javax.vecmathx.matrix.MtrxReadI;

/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 3/04/2006, Time: 17:07:23
 */
public interface UsrPopMtrxI extends MtrxReadI
{
//  public int getId(int idx);
//  public void setName(String name);
//  public String getName();
}
