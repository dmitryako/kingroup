package kingroup_v2.refs.wang2002;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 27/09/2006, Time: 09:55:03
 */
public class Wang2002
{
  public static final String REFERENCE = "Wang (2002) Genetics 160 p1203";
}
