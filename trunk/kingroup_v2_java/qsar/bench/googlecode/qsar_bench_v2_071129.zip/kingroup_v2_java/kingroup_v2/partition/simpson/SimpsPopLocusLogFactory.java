package kingroup_v2.partition.simpson;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 11/08/2005, Time: 15:54:34
 */
public class SimpsPopLocusLogFactory{
}