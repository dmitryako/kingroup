package kingroup_v2.lynch;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 12/04/2006, Time: 12:29:14
 */
public class Lynch
{
  public static final String REFERENCE = "Lynch & Ritland (1999) Genetics 152 p1753";
}
