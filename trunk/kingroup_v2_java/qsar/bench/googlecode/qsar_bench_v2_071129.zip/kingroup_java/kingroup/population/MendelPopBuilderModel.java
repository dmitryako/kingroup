package kingroup.population;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 2/03/2005, Time: 09:11:28
 */
public class MendelPopBuilderModel extends PopBuilderModelOLD {
}
