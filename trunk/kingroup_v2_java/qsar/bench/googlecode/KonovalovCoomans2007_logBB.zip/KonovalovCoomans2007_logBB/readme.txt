This directory contains data sets from 

Konovalov, D. A.; Coomans, D.; Deconinck, E.; Vander Heyden, Y. Benchmarking of QSAR models for Blood-Brain Barrier Permeation. J. Chem. Inf. Model. 2007, 47, 1648-1656.
