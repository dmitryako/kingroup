This directory contains data sets from 

Konovalov, D. A.; Sim, N.; Deconinck, E.; Vander Heyden, Y.; Coomans, D. 
Statistical Confidence for Variable Selection in QSAR models via Monte Carlo Cross-Validation. J. Chem. Inf. Model. 2008, 48, 370-383.