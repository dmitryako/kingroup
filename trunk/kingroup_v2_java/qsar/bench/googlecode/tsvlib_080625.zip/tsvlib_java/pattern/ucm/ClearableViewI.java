package pattern.ucm;
/**
 * Copyright: www.DmitryKonovalov.org, jc138691, 17/04/2007, 10:20:19
 */
public interface ClearableViewI
{
  public void clear();
}
