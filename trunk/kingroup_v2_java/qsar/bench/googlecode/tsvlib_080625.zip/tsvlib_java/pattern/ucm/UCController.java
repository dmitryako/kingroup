package pattern.ucm;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 13/09/2005, Time: 13:06:13
 */
public interface UCController {
  public boolean run();
}
