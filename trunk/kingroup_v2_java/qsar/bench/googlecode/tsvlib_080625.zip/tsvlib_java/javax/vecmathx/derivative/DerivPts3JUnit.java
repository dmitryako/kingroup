package javax.vecmathx.derivative;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import numeric.functor.FuncPolynom;

import javax.vecmathx.function.FunctionXY;
import javax.vecmathx.grid.StepGrid;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * See www.kingroup.org for more details.
 * User: jc138691, Date: Dec 6, 2004, Time: 4:18:12 PM
 */
public class DerivPts3JUnit extends TestCase {
  static double eps18 = 1e-18;
  public static Test suite() {
    return new TestSuite(DerivPts3JUnit.class);
  }
  public static void main(String[] args) {
    junit.textui.TestRunner.run(suite());
  }
  public void testDeriv() {
    int idx = 0;
    double first = 0;
    double last = 1;
    int size = 3;
    StepGrid x = new StepGrid(first, last, size);
    double[] coeff = {1};
    FunctionXY f = new FunctionXY(x, new FuncPolynom(coeff));
    FunctionXY df = new DerivPts3(f);
    assertEquals(0, df.get(idx++), eps18);
    assertEquals(0, df.get(idx++), eps18);
    assertEquals(0, df.get(idx++), eps18);
    double[] c2 = {0, 0.5};
    f = new FunctionXY(x, new FuncPolynom(c2));
    df = new DerivPts3(f);
    idx = 0;
    assertEquals(0.5, df.get(idx++), eps18);
    assertEquals(0.5, df.get(idx++), eps18);
    assertEquals(0.5, df.get(idx++), eps18);
    double[] c3 = {0, 0, 0.5};
    f = new FunctionXY(x, new FuncPolynom(c3));
    double[] c3_deriv = {0, 1};
    df = new FunctionXY(x, new FuncPolynom(c3_deriv));
    FunctionXY ndf = new DerivPts3(f); // numeric derivative
    idx = 0;
    assertEquals(df.get(idx), ndf.get(idx), eps18);
    idx++;
    assertEquals(df.get(idx), ndf.get(idx), eps18);
    idx++;
    assertEquals(df.get(idx), ndf.get(idx), eps18);
    idx++;
  }
}
