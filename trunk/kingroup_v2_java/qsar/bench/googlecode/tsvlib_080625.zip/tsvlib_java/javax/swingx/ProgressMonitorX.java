package javax.swingx;
/** JKinship    Copyright (C) 2003  Dr.D.A.Konovalov
 */
import javax.langx.MemoryInfo;
import javax.swing.*;
import java.awt.*;

public class ProgressMonitorX extends ProgressMonitor {
  private static ProgressMonitorX instance = null;
  private int max_val_ = 100;
  private int min_val_ = 0;
  private MemoryInfo memory = new MemoryInfo();
  private static Component parent = null;
  public static ProgressMonitorX getInstance() {
    if (instance != null)
      return instance;
    instance = new ProgressMonitorX(parent);
    return instance;
  }
  public void close() {
    super.close();
    instance = null;
  }
  synchronized public boolean isCanceled(int curr_val, int min_val, int max_val) {
    if (isCanceled())
      return true;
    if (min_val_ != min_val)
      setMinimum(min_val);
    if (max_val_ != max_val)
      setMaximum(max_val);
    setNote(memory.getStatus());
    setProgress(curr_val);
    return false;
  }
  public ProgressMonitorX(Component frame) {
    super(frame, "Monitor", "", 1, 100);
    setMillisToPopup(1000);  // default is 2000
  }
  public ProgressMonitorX(Component frame, String name) {
    super(frame, name, "", 1, 100);
    setMillisToPopup(1000);  // default is 2000
  }
  public static ProgressMonitorX setFrame(Component newframe) {
    parent = newframe;
    instance = new ProgressMonitorX(parent);
    return instance;
  }
  public static void setInstance(ProgressMonitorX v) {
    instance = v;
  }
}
