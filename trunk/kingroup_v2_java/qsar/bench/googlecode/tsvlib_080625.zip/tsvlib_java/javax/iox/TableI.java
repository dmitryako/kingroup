package javax.iox;
/**
 * Copyright: www.DmitryKonovalov.org, jc138691, 30/03/2007, 10:01:03
 */
public class TableI
{
}
