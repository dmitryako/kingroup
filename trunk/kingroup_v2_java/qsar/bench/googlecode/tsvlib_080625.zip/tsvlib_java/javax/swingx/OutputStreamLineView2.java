package javax.swingx;
/**
 * Copyright: www.DmitryKonovalov.org, jc138691, 17/04/2007, 12:28:36
 */
public class OutputStreamLineView2
{
}
