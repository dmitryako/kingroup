package javax.iox;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 24/09/2005, Time: 10:22:30
 */
public class IOX {
  public static final String eol = System.getProperty("line.separator");
}
