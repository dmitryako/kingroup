package javax.utilx.pair;
import java.util.BitSet;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * See www.kingroup.org for more details.
 * User: jc138691, Date: Oct 14, 2004, Time: 2:44:18 PM
 */
public class BitSetPair {
  public final BitSet a;
  public final BitSet b;
  public BitSetPair(BitSet a, BitSet b) {
    this.a = a;
    this.b = b;
  }
}
