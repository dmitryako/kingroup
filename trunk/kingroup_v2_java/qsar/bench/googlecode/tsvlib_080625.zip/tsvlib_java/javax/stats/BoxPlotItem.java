package javax.stats;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 20/06/2005, Time: 08:44:13
 */
public class BoxPlotItem {
  public BoxPlotItem(double[] arr) {
    //TODO
  }
  public double getMean() {
    return 0;
  }
  public double getMedian() {
    return 0;
  }
  public double getQ1() {
    return 0;
  }
  public double getQ3() {
    return 0;
  }
  public double getMaxOutlier() {
    return 0;
  }
  public double getMaxRegularValue() {
    return 0;
  }
  public double getMinOutlier() {
    return 0;
  }
  public double getMinRegularValue() {
    return 0;
  }
}
