package javax.utilx;
import java.util.HashSet;

/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 3/03/2006, Time: 11:47:17
 */
public class IntHashSet extends HashSet<Integer>
{
}
