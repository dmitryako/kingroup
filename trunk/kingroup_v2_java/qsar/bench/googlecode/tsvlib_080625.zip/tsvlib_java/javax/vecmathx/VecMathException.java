package javax.vecmathx;
public class VecMathException extends RuntimeException {
  public VecMathException(String error) {
    super(error);
  }
}
