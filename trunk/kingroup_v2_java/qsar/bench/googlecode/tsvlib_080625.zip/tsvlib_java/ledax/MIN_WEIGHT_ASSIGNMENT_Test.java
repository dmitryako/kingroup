package ledax;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * See www.kingroup.org for more details.
 * User: jc138691, Date: Oct 27, 2004, Time: 8:56:41 AM
 */
public class MIN_WEIGHT_ASSIGNMENT_Test extends TestCase {
  public static void main(String[] args) {
    junit.textui.TestRunner.run(suite());
  }
  public static Test suite() {
    return new TestSuite(MIN_WEIGHT_ASSIGNMENT_Test.class);
  }
  protected void setUp() {
  }
  public void testCalc() {
  }
}
