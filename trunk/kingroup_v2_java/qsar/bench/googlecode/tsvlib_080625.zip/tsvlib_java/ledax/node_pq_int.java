package ledax;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * See www.kingroup.org for more details.
 * User: jc138691, Date: Oct 27, 2004, Time: 11:47:51 AM
 */
final public class node_pq_int extends node_pq_int_linkedlist {
}
