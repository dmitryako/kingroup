package ledax;
import java.util.ArrayList;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * See www.kingroup.org for more details.
 * User: jc138691, Date: Oct 26, 2004, Time: 11:29:44 AM
 */
public class list_node extends ArrayList {
  public void append(Object obj) {
    add(obj);
  }
}
