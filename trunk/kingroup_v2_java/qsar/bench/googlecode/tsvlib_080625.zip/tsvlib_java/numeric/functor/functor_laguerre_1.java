package numeric.functor;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * See www.kingroup.org for more details.
 * User: jc138691, Date: Dec 2, 2004, Time: 2:50:17 PM
 */
public class functor_laguerre_1 implements Func1DI {
  final private double alpha_;
  final private double lambda_;
  public functor_laguerre_1(final double alpha, final double lambda) {
    alpha_ = alpha;
    lambda_ = lambda;
  }
  public double calc(double x) {
    return alpha_ + 1 - lambda_ * x;
  }
}