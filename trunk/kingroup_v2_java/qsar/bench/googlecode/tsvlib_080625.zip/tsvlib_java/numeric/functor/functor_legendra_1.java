package numeric.functor;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * See www.kingroup.org for more details.
 * User: jc138691, Date: Dec 10, 2004, Time: 10:40:09 AM
 */
public class functor_legendra_1 implements Func1DI {
  public double calc(double x) {
    return 2. * x - 1;
  }
}