package numeric.functor;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * See www.kingroup.org for more details.
 * User: jc138691, Date: Dec 9, 2004, Time: 3:18:46 PM
 */
public class FuncPow2 implements Func1DI {
  public double calc(double x) {
    return x * x;
  }
}
