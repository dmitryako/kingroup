package numeric.functor;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * See www.kingroup.org for more details.
 * User: jc138691, Date: Dec 10, 2004, Time: 1:51:04 PM
 */
public class functor_chebyshev_kind2_1 implements Func1DI {
  public double calc(double x) {
    return 2. * x;
  }
}
