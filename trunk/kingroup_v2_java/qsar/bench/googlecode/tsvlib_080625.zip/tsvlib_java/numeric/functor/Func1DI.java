package numeric.functor;
public interface Func1DI {
  public double calc(double x);
}
