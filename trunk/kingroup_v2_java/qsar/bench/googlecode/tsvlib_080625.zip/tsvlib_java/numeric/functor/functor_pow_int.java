package numeric.functor;
import javax.mathx.MathX;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 19/03/2005, Time: 15:49:06
 */
public class functor_pow_int implements Func1DI {
  private final double a;
  private final int k;
  public functor_pow_int(double a, int k) {
    this.a = a;
    this.k = k;
  }
  public double calc(double x) {
    return a * MathX.pow(x, k);
  }
}