package numeric.functor;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * See www.kingroup.org for more details.
 * User: jc138691, Date: Dec 1, 2004, Time: 12:52:41 PM
 */
public class functor_const implements Func1DI {
  final private double c0_;
  public functor_const(double v) {
    c0_ = v;
  }
  public double calc(double x) {
    return c0_;
  }
}
