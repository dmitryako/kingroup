package stlx.valarrayx;
import stlx.duff_loop;
import numeric.functor.Func1DI;

import javax.iox.LOG;
import javax.vecmath.GVector;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * This code is licensed under the GPL license (see www.gnu.org) for academic,
 * not-for-profit use or for use within other Open Source software (see www.opensource.org).
 * See www.kingroup.org for more details.
 * User: jc138691
 * Date: Sep 24, 2004, Time: 5:12:38 PM
 */
public class valarray extends GVector {

  public static double[] asArray(valarray arr) {
    double[] res = new double[arr.size()];
    for (int i = 0; i < res.length; i++) {
      res[i] = arr.get(i);
    }
    return res;
  }

  public valarray(double[] x) {
    super(x);
  }
  public valarray(valarray x) {
    super(x);
  }
  public valarray(int size) {
    super(size);
  }
  final public double last() {
    return get(size() - 1);
  }
  final public double first() {
    return get(0);
  }
  final public int size() {
    return getSize();
  }
  final public void set(final int i, final double val) {
    setElement(i, val);
  }
  final public double get(final int i) {
    return getElement(i);
  }
  final public double duff_dot(valarray f) {
    LOG.error(this, "GVector.dot() is faster", " re-run valarray_junit");
    return duff_loop.dot(this, f);
  }
  final public double duff_dot(GVector f) {
    LOG.error(this, "GVector.dot() is faster", " re-run valarray_junit");
    return duff_loop.dot(this, f);
  }
  final public void apply(Func1DI f) {
    duff_loop.apply(this, f);
  }
  final public void mul(final int i, final double byVal) {
    final double tmp = get(i);
    setElement(i, tmp * byVal);
  }
  public void safeDivide(valarray r) {
    int validSize = Math.min(r.size(), size());
    for (int i = 0; i < validSize; i++) {
      double top = get(i);
      double bottom = r.get(i);
      if (top != 0 && bottom != 0)
        set(i, top / bottom);
    }
  }
  final public void scale(valarray f) {
    duff_loop.scale(this, f);
  }
  public void addSafeSLOW(valarray from) {
    if (size() >= from.size()) {
      addShorterSLOW(from);
      return;
    }
    valarray tmp = new valarray(this);
    setSize(from.size());
    zero();
    addShorterSLOW(tmp);
    addShorterSLOW(from);
  }
  private void addShorterSLOW(valarray from) {
    for (int j = 0; j < from.size(); j++) {
      this.setElement(j, get(j) + from.get(j));
    }
  }
}
