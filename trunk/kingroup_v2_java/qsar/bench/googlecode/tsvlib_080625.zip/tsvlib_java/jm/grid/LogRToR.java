package jm.grid;
import numeric.functor.Func1DI;
import numeric.functor.functor_exp;
import stlx.valarrayx.valarray;

import javax.vecmathx.function.FunctionXY;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 11/03/2005, Time: 10:22:28
 */
public class LogRToR extends FunctionXY {
  private valarray R2;
  private valarray divSqrtR;
  private final FunctionXY mapLogRToR2;
  // Just to help keeping track
  // equal step in x=ln(r)
  public LogRToR(valarray x) {
    super(x, new functor_exp(1));
    mapLogRToR2 = new FunctionXY(x, new functorLogRToR2());
  }
  public FunctionXY getMapLogRToR2() {
    return mapLogRToR2;
  }
  public valarray getR2() {
    if (R2 == null)
      R2 = new FunctionXY(x, new functorLogRToR2());
    return R2;
  }
  public valarray getDivSqrtR() {
    if (divSqrtR == null)
      divSqrtR = new FunctionXY(x, new functorLogRToDivSqrtR());
    return divSqrtR;
  }
  private class functorLogRToR implements Func1DI {
    // f(x)=r
    public double calc(double x) {
      return Math.exp(x);
    }
  }
  private class functorLogRToR2 extends functorLogRToR {
    // f(x)=r^2
    public double calc(double x) {
      double r = super.calc(x);
      return r * r;
    }
  }
  private class functorLogRToDivSqrtR extends functorLogRToR {
    // f(x)=1/sqrt(r)
    public double calc(double x) {
      double cr = super.calc(x);
      return 1. / Math.sqrt(cr);
    }
  }
}
