package jm.shell;
import jm.angular.LSCoupling;

import javax.iox.LOG;
import javax.vecmathx.function.FunctionArray;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * See www.kingroup.org for more details.
 * User: jc138691, Date: Dec 3, 2004, Time: 5:14:01 PM
 */
public class FanoFactory {
  public static FanoArray makeTwoElec(LSCoupling LS, int N, int L, FunctionArray from) {
    return makeTwoElecFrom(null, LS, N, L, from);
  }
//   public static FanoArray makeTwoElecNL(LSCoupling LS, int N, int maxL, FunctionArray from) {
//   }
  public static FanoArray makeTwoElecFrom(FanoArray from, LSCoupling LS, int N, int L
    , FunctionArray fromArr) {
    FanoArray res = new FanoArray(from);
//      if (from == null)
//         from = new FanoArray();
    for (int n = 0; n < N; n++) {
      Shell sh = new Shell(n, fromArr.get(n), 2, L, LS);
      if (sh.isValid()) {
        FanoConfig fc = new FanoTwoElec(sh);
        //         LOG.trace(fromArr, "config(n=n2)=", fc.toString());
        res.add(fc);
      }
      sh = new Shell(n, fromArr.get(n), L);
      for (int n2 = n + 1; n2 < N; n2++) {
        Shell sh2 = new Shell(n2, fromArr.get(n2), L);
        if (!sh2.isValid())
          continue;
        FanoConfig fc = new FanoTwoElec(sh).addShell(sh2, LS);
//            LOG.trace(fromArr, "config(n2>n)=", fc.toString());
        res.add(fc);
      }
    }
    LOG.trace(fromArr, "from=\n", res.toString());
    return res;
  }
  public static FanoArray makeTwoElecSameN(LSCoupling LS, int N, FunctionArray from) {
    FanoArray res = new FanoArray();
    for (int n = 0; n < N; n++) {
      Shell sh = new Shell(n, from.get(n), 2, 0, LS);
      FanoConfig c = new FanoTwoElec(sh);
      res.add(c);
    }
    LOG.trace(from, "res=\n", res.toString());
    return res;
  }
  public static FanoArray makeOneElec(int N, int L, FunctionArray from) {
    FanoArray res = new FanoArray();
    for (int n = 0; n < N; n++) {
      Shell sh = new Shell(n, from.get(n), L);
      FanoConfig c = new FanoConfig(sh);
      res.add(c);
    }
    return res;
  }
}
