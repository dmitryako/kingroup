package jm.atom;
import jm.shell.Shell;

import javax.vecmathx.function.FunctionXY;
import javax.vecmathx.integration.Integral;
import javax.vecmathx.integration.Weights;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * See www.kingroup.org for more details.
 * User: jc138691, Date: Dec 6, 2004, Time: 5:45:19 PM
 */
public class Slater extends Integral {
  public Slater(Weights w) {
    super(w);
  }
  protected FunctionXY calcOneElecDensity(Shell sh, Shell sh2) {
    return null;
  }
  protected double calcOneElecKin(Shell sh, Shell sh2) {
    return 0;
  }
  protected double calcOneElecZPot(double z, Shell sh, Shell sh2) {
    return 0;
  }
}
