package jm.grid;
import stlx.valarrayx.valarray;

import javax.vecmathx.grid.StepGrid;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 17/03/2005, Time: 18:01:14
 */
public class WeightsLogCR extends WeightsLogR {
  private valarray wCR2;
  private valarray wCR2DivR;
  private final LogCRToR logCRToR;
  public WeightsLogCR(StepGrid x) {
    super(x);
    logCRToR = new LogCRToR(x);
  }
  public valarray withCR2DivR() {
    if (wCR2DivR == null) {
      wCR2DivR = new valarray(logCRToR.getCR2DivR());
      wCR2DivR.scale(this);
    }
    return wCR2DivR;
  }
  public LogCRToR getLogCRToR() {
    return logCRToR;
  }
  public valarray withCR2() {
    if (wCR2 == null) {
      wCR2 = new valarray(logCRToR.getCR2());
      wCR2.scale(this);
    }
    return wCR2;
  }
  public valarray getNormWeights() {
    return withCR2();
  }
}
