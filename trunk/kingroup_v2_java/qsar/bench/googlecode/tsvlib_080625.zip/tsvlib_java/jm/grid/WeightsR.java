package jm.grid;
import numeric.functor.functor_pow_int;
import stlx.valarrayx.valarray;

import javax.vecmathx.function.FunctionXY;
import javax.vecmathx.grid.StepGrid;
import javax.vecmathx.integration.BooleWeights;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 19/03/2005, Time: 15:42:25
 */
public class WeightsR extends BooleWeights {
//   private valarray wDivR2;
  private valarray divR2;
  private valarray divR;
  public WeightsR(StepGrid x) {
    super(x);
  }
//   public valarray withDivR2() {
//      if (wDivR2 == null) {
//         wDivR2 = new FunctionXY(this.x, new functor_pow_int(1., -2));
//         wDivR2.scale(this);
//      }
//      return wDivR2;
//   }
  public valarray getDivR2() {
    if (divR2 == null) {
      divR2 = new FunctionXY(this.x, new functor_pow_int(1., -2));
    }
    return divR2;
  }
  public valarray getDivR() {
    if (divR == null) {
      divR = new FunctionXY(this.x, new functor_pow_int(1., -1));
    }
    return divR;
  }
}
