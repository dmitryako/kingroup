package jm.shell;
import jm.angular.LSCoupling;

import java.util.ArrayList;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * See www.kingroup.org for more details.
 * User: jc138691, Date: Dec 3, 2004, Time: 4:20:03 PM
 */
public class FanoConfig {
  private LSCoupling LS;
  private ArrayList arr = new ArrayList();
  public FanoConfig(Shell sh) {
    LS = new LSCoupling(sh.LS);
    arr.add(sh);
  }
  public FanoConfig addShell(Shell sh, LSCoupling LS) {
    arr.add(sh);
    this.LS = LS;
    return this;
  }
  public Shell getShell(int i) {
    return (Shell) arr.get(i);
  }
  final public boolean equals(Object obj) {
    if (this == obj)
      return true;
    FanoConfig fc = (FanoConfig) obj;
    if (fc.size() != this.size())
      return false;
    if (!fc.LS().equals(LS()))
      return false;
    for (int s = 0; s < arr.size(); s++) {
      Shell sh = this.getShell(s);
      Shell sh2 = fc.getShell(s);
      if (!sh.equals(sh2))
        return false;
    }
    return true;
  }
  private int size() {
    return arr.size();
  }
  final public LSCoupling LS() {
    return LS;
  }
  public String toString() {
    StringBuffer buff = new StringBuffer();
//      if (base == null)
//         buff.append(getShell.toString());
//      else
//         buff.append(base.toString()).append(getShell.toString());
    for (int i = 0; i < arr.size(); i++) {
      buff.append(getShell(i).toString());
    }
    buff.append(" ").append(LS.toString());
    return buff.toString();
  }
}
