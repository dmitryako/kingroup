package jm.shell;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 22/03/2005, Time: 11:32:13
 */
public class ShellPair {
  public final Shell a;
  public final Shell b;
  public ShellPair(Shell a, Shell b) {
    this.a = a;
    this.b = b;
  }
}
