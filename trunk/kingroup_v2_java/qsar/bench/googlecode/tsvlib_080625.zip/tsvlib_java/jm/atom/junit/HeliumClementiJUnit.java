package jm.atom.junit;
import Jama.EigenvalueDecomposition;
import jm.JMatrix;
import jm.angular.LSCoupling;
import jm.angular.Spin;
import jm.atom.HamiltonianMatrix;
import jm.atom.SlaterLogCR;
import jm.atom.SystemTwoElec;
import jm.atom.coulomb.CoulombFactory;
import jm.grid.LogCRToR;
import jm.grid.WeightsLogCR;
import jm.laguerre.LaguerreLogCR;
import jm.shell.FanoArray;
import jm.shell.FanoFactory;
import jm.shell.FanoTwoElec;
import jm.shell.Shell;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import stlx.duff_loop;
import stlx.valarrayx.valarray;

import javax.iox.LOG;
import javax.utilx.arrays.vec.Vec;
import javax.vecmathx.function.FunctionArray;
import javax.vecmathx.function.FunctionXY;
import javax.vecmathx.grid.StepGrid;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 29/03/2005, Time: 17:15:59
 */
public class HeliumClementiJUnit extends TestCase {
  public static Test suite() {
    return new TestSuite(HeliumClementiJUnit.class);
  }
  public static void main(String[] args) {
    junit.textui.TestRunner.run(suite());
  }
  public void testClementiSingleZeta() {
    LOG.setTrace(true);
    double FIRST = -5;
    int NUM_STEPS = 261;
    double LAST = 7; // exp(7) = 1096
    StepGrid x = new StepGrid(FIRST, LAST, NUM_STEPS);
    WeightsLogCR wCR = new WeightsLogCR(x);
    LogCRToR xToR = wCR.getLogCRToR();
    valarray r = xToR;

    // from p445 of Clementi Roetti, Atomic Data 14, 177 (1974)
    double Zeff = 1.6875;// from p445 of Clementi Roetti, Atomic Data 14, 177 (1974)
    FunctionXY f = CoulombFactory.makeP1s(r, Zeff);
    f.setX(xToR.x); // MUST change grid for derivatives
    f.scale(xToR.getDivSqrtCR());
    double res = duff_loop.dot(f, f, wCR.withCR2());
    assertEquals(0, Math.abs(res - 1), 3e-14);
    LSCoupling LS = new LSCoupling(0, Spin.SINGLET);
    Shell sh = new Shell(1, f, 2, LS.L, LS);
    FanoTwoElec fc = new FanoTwoElec(sh);
    SlaterLogCR slater = new SlaterLogCR(wCR);
    SystemTwoElec sys = new SystemTwoElec(-2., slater);
    double kin = sys.calcKin(fc, fc);
//      job.addLine(CTestableDH(new CTestableD(He.calc_kin(c_1s2_He, c_1s2_He)))
//         , 2.8476562, "Kin.E. He_1s2", 8e-6);
    assertEquals(0, Math.abs(2.84765625 - kin), 2e-11);

//      job.addLine(CTestableDH(new CTestableD(He.calc_pot(c_1s2_He, c_1s2_He)))
//         , -5.6953125, "Pot.E. He_1s2", 7e-11);
    double pot = sys.calcPot(fc, fc);
    assertEquals(0, Math.abs(-5.6953125 - pot), 2e-11);
    assertEquals(0, Math.abs(-2. - pot / kin), 8e-12);

//      job.addLine(CTestableDH(new CTestableD(He.calc(c_1s2_He, c_1s2_He)))
//         , -2.8476562, "He_1s2", 8e-6);
    res = sys.calcTot(fc, fc);
    assertEquals(0, Math.abs(-2.84765625 - res), 4e-12);
  }
  public void testClementiLimitOneConfig() {
    LOG.setTrace(true);
    double FIRST = -5;
    int NUM_STEPS = 381;
    double LAST = 7; // exp(7) = 1096
    StepGrid x = new StepGrid(FIRST, LAST, NUM_STEPS);
    WeightsLogCR w = new WeightsLogCR(x);
    LogCRToR xToR = w.getLogCRToR();
    int L = 0;
    double Zeff = 1.6875;// from p445 of Clementi Roetti, Atomic Data 14, 177 (1974)
    int alpha = 2 * L + 2;
    double lambda = 2. * Zeff;
    int N = 12;
    FunctionArray arr = new LaguerreLogCR(xToR, N, alpha, lambda);
    JMatrix.trimTailSLOW(arr);
    double res = w.calcMaxNormError(arr);
    assertEquals(0, res, 2e-11);
    SlaterLogCR slater = new SlaterLogCR(w);
    LSCoupling LS = new LSCoupling(0, Spin.SINGLET);
    SystemTwoElec sys = new SystemTwoElec(-2., slater);

    // One config hartree-fock limit
    double kin = 2.8617128;// from Clementi, p185
    double pot = -5.7233927;// from Clementi, p185
    double tot = -2.8616799;
    assertEquals(kin + pot, tot, 6e-22);
    FanoArray basis = FanoFactory.makeTwoElecSameN(LS, N, arr);
    HamiltonianMatrix H = new HamiltonianMatrix(basis, sys);
    EigenvalueDecomposition eig = H.eig();
    LOG.report(this, "H=" + Vec.toString(eig.getRealEigenvalues()));
    double e0 = eig.getRealEigenvalues()[0];
    LOG.report(this, "\nkin+pot="
      + (kin + pot) + "\n   e[0]=" + e0);
    assertEquals(0, Math.abs(-2.8615628084911 - e0), 1e-13); //
    assertEquals(0, e0 - tot, 2e-4);
    FunctionXY conf = H.calcDensity(eig, 0);
//      LOG.saveToFile(valarray.asArray(x), valarray.asArray(conf), "wf", "He_ground_density.csv");
    res = duff_loop.dot(conf, w);
    assertEquals(2, res, 3e-15);
  }
}
