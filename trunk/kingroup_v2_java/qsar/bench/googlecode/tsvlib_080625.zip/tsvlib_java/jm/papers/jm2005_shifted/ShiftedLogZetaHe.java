package jm.papers.jm2005_shifted;
import jm.angular.LSCoupling;
import jm.angular.Spin;
import jm.atom.SlaterLogCR;
import jm.atom.SystemTwoElec;
import jm.atom.coulomb.CoulombFactory;
import jm.grid.LogCRToR;
import jm.grid.WeightsLogCR;
import jm.shell.FanoTwoElec;
import jm.shell.Shell;
import junit.framework.Test;
import junit.framework.TestSuite;
import stlx.duff_loop;
import stlx.valarrayx.valarray;

import javax.vecmathx.function.FunctionXY;
import javax.vecmathx.grid.StepGrid;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 4/04/2005, Time: 11:38:02
 */
public class ShiftedLogZetaHe extends ShiftedLogTestCase {
  public static Test suite() {
    return new TestSuite(ShiftedLogZetaHe.class);
  }
  public static void main(String[] args) {
    junit.textui.TestRunner.run(suite());
  }
  public void test_He_1S_LogCR() {
    double Z = 2;
    StepGrid x = new StepGrid(FIRST - Math.log(Z), NUM_STEPS, STEP);
    WeightsLogCR w = new WeightsLogCR(x);
    LogCRToR xToR = w.getLogCRToR();
    valarray r = xToR;

    // WF
    double ZETA = 1.6875;// from p445 of Clementi Roetti, Atomic Data 14, 177 (1974)
    int L = 0;
    FunctionXY f = CoulombFactory.makeP1s(r, ZETA);
    f.setX(xToR.x); // MUST change grid for derivatives
    f.scale(xToR.getDivSqrtCR());
    double res = duff_loop.dot(f, f, w.withCR2());
    assertAndView("He norm(ZETA, LogCR)=", res - 1, 3e-12);
    double test0 = -2.84765625;
    double testKin = -test0;
    double testPot = 2 * test0;
    LSCoupling LS = new LSCoupling(L, Spin.SINGLET);
    Shell sh = new Shell(1, f, 2, LS.L, LS);
    FanoTwoElec fc = new FanoTwoElec(sh);
    SlaterLogCR slater = new SlaterLogCR(w);
    SystemTwoElec sys = new SystemTwoElec(-Z, slater);
    double kin = sys.calcKin(fc, fc);
    assertAndView("Hy kin(LogCR)=", testKin - kin, 2e-10);
    double pot = sys.calcPot(fc, fc);
    assertAndView("Hy pot(LogCR)=", testPot - pot, 1e-10);
    assertAndView("Hy kin/pot(LogCR)=", -2. - pot / kin, 2e-10);
    res = sys.calcTot(fc, fc);
    assertAndView("Hy tot(LogCR)=", test0 - res, 2e-10);
  }
}