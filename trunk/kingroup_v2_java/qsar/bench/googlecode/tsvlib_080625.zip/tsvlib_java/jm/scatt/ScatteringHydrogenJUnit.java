package jm.scatt;
import Jama.EigenvalueDecomposition;
import jm.angular.LSCoupling;
import jm.angular.Spin;
import jm.atom.HamiltonianMatrix;
import jm.atom.SlaterLogCR;
import jm.atom.SystemTwoElec;
import jm.bspline.BSplineFactory;
import jm.bspline.BSplineHeJUnit;
import jm.bspline.junit.BSplineLogCRJUnit;
import jm.grid.WeightsLogCR;
import jm.shell.FanoArray;
import jm.shell.FanoFactory;
import junit.framework.Test;
import junit.framework.TestSuite;

import javax.iox.LOG;
import javax.utilx.arrays.vec.Vec;
import javax.vecmathx.function.FunctionArray;
import javax.vecmathx.grid.StepGrid;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 19/04/2005, Time: 14:43:57
 */
public class ScatteringHydrogenJUnit extends BSplineLogCRJUnit {
  public static Test suite() {
    return new TestSuite(BSplineHeJUnit.class);
  }
  public static void main(String[] args) {
    junit.textui.TestRunner.run(suite());
  }
  public void testLimitNS() {
    LOG.setTrace(true);
    double FIRST = -2;
    int NUM_STEPS = 441;
    double LAST = 2; //
    StepGrid x = new StepGrid(FIRST, LAST, NUM_STEPS);
    WeightsLogCR w = new WeightsLogCR(x);
    int k = 5;
    int N = 20;
    FunctionArray arr = BSplineFactory.makeBSplineLogCR(w, N, k);
    double res = w.calcMaxNormError(arr);
    assertEquals(0, res, NORM_ERROR);
    SlaterLogCR slater = new SlaterLogCR(w);
    LSCoupling S1 = new LSCoupling(0, Spin.SINGLET);
    SystemTwoElec sys = new SystemTwoElec(-2., slater);

    // Multi-Config Hartree-Fock with 1s2+...+4s2
    double tot = -2.878990; // from p.164 of Froese-Fischer
    int L = 0;
    FanoArray basis = FanoFactory.makeTwoElec(S1, N, L, arr);
    HamiltonianMatrix H = new HamiltonianMatrix(basis, sys);
    EigenvalueDecomposition eig = H.eig();
    LOG.report(this, "H=" + Vec.toString(eig.getRealEigenvalues()));
    double e0 = eig.getRealEigenvalues()[0];
    LOG.report(this, "Multi-Config Hartree-Fock with 1s2+...+4s2"
      + "\ntot =" + tot
      + "\ne[0]=" + e0);
    assertEquals(0, Math.abs(e0 - tot), 6e-4);
  }
}
