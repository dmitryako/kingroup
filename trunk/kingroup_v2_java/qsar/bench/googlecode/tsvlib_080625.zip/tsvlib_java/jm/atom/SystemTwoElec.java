package jm.atom;
import jm.shell.FanoConfig;
import jm.shell.FanoTwoElec;
import jm.shell.Shell;
import jm.shell.ShellPair;

import javax.mathx.MathX;
import javax.utilx.pair.DoublePair;
import javax.vecmathx.function.FunctionXY;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * See www.kingroup.org for more details.
 * User: jc138691, Date: Dec 4, 2004, Time: 6:01:07 PM
 */
public class SystemTwoElec extends Atom {
  private final static int TWO_ELEC = 2;
  private final SlaterLogCR siLogCR;
  //public static final SystemTwoElec HELIUM = new SystemTwoElec(-2);
  public SystemTwoElec(double z, SlaterLogCR si) {
    super(z, si);
    siLogCR = si;
  }
  public int getNumElec() {
    return TWO_ELEC;
  }
  public KinPotEnergy calcConfigEnergy(FanoConfig fc, FanoConfig fc2) {
    assertLS(fc, fc2);
    // He, H+e, any two electron atomic system
    ShellPair sp = ((FanoTwoElec) fc).getShellPair();
    Shell a = sp.a;
    Shell b = sp.b;
    // <a(1) b(2) |...|a2(1) b2(2)>
    ShellPair sp2 = ((FanoTwoElec) fc2).getShellPair();
    Shell a2 = sp2.a;
    Shell b2 = sp2.b;
    KinPotEnergy dir = calcShellPairEnergy(fc.LS().L, a, b, a2, b2); // potential only
    KinPotEnergy exc = null;
    if (a2.nL.equals(b2.nL))
      exc = new KinPotEnergy(dir);
    else
      exc = calcShellPairEnergy(fc.LS().L, a, b, b2, a2);
    int prty = 0; // see (21); no spectator electrons for He
    //exc *= MathX.pow(-1, (int)((CL)fc.s() + sp2.a()->nl().L() + sp2.b()->nl().L() + CL(1)) - (int)fc.L() );
    double excMult = MathX.pow(-1, (fc.LS().S.getInt() + a2.nL.L + b2.nL.L + 1) - fc.LS().L);
    exc.kin *= excMult;
    exc.pot *= excMult;
    DoublePair norm = normQ(a, b, a2, b2, prty);
    KinPotEnergy res = new KinPotEnergy(norm.a * dir.kin + norm.b * exc.kin
      , norm.a * dir.pot + norm.b * exc.pot);
    return res;
  }
  public FunctionXY calcConfigDensity(FanoConfig fc, FanoConfig fc2) {
    assertLS(fc, fc2);
    // He, H+e, any two electron atomic system
    ShellPair sp = ((FanoTwoElec) fc).getShellPair();
    Shell a = sp.a;
    Shell b = sp.b;
    // <a(1) b(2) |...|a2(1) b2(2)>
    ShellPair sp2 = ((FanoTwoElec) fc2).getShellPair();
    Shell a2 = sp2.a;
    Shell b2 = sp2.b;
    FunctionXY dir = calcOneElecDensity(a, b, a2, b2); // potential only
    FunctionXY exc = null;
    if (a2.nL.equals(b2.nL)) {
      if (dir != null)
        exc = new FunctionXY(dir);
    } else {
      exc = calcOneElecDensity(a, b, b2, a2);
    }
    if (exc == null && dir == null) {
      return null;
    }
    int prty = 0; // see (21); no spectator electrons for He
    double excMult = MathX.pow(-1, (fc.LS().S.getInt() + a2.nL.L + b2.nL.L + 1) - fc.LS().L);
    DoublePair norm = normQ(a, b, a2, b2, prty);
    if (dir != null) {
      dir.scale(norm.a);
    }
    if (exc != null) {
      exc.scale(excMult);
      exc.scale(norm.b);
    }
    if (dir != null && exc != null) {
      dir.add(exc);
    } else if (dir == null) {
      dir = exc;
    }
    return dir;
  }
  public double calcRk(Shell a, Shell b, Shell a2, Shell b2, int kk) {
    return RkLogCR.calcRkLogCR(siLogCR.getWeightsLogCR()
      , a.wf, b.wf, a2.wf, b2.wf, kk);
  }
}
