package jm.atom;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 7/04/2005, Time: 07:29:11
 */
public class Hydrogen {
  public static double[] EXACT_1S = {-0.527751014    // Pekeris 1962 PhysRev 126, p1470
    //, -0.4981}; // Pekeris 1962 PhysRev 126, p1470
    , -0.5};
}
