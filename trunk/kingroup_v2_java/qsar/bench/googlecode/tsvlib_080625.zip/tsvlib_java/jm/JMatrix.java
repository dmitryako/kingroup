package jm;
import jm.atom.KinPotEnergy;

import javax.vecmathx.function.FunctionArray;
import javax.vecmathx.function.FunctionXY;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 22/03/2005, Time: 12:08:09
 */
public class JMatrix {
  private static final double IGNORE = 1e-32;
  public static boolean ignore(double v) {
    return Math.abs(v) < IGNORE;
  }
  public static boolean ignore(KinPotEnergy e) {
    return ignore(e.kin + e.pot);
  }
  public static void trimTailSLOW(FunctionXY f) {
    int newSize = f.size();
    for (int i = f.size() - 1; i >= 0; i--) {
      if (ignore(f.get(i)))
        newSize--;
      else
        break;
    }
    f.setSize(newSize);
  }
  public static void trimTailSLOW(FunctionArray arr) {
    for (int i = 0; i < arr.size(); i++) {
      trimTailSLOW(arr.get(i));
    }
  }
}
