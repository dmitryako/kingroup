package jm.atom;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * See www.kingroup.org for more details.
 * User: jc138691, Date: Dec 6, 2004, Time: 5:32:45 PM
 */
public class AtomGridR {
}
