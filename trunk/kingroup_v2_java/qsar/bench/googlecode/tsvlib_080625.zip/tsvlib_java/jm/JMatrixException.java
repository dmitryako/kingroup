package jm;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 11/03/2005, Time: 15:52:52
 */
public class JMatrixException extends RuntimeException {
  public JMatrixException(String error) {
    super(error);
  }
}