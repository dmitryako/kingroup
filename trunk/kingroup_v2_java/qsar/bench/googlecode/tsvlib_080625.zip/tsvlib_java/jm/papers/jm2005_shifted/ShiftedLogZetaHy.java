package jm.papers.jm2005_shifted;
import jm.angular.LSCoupling;
import jm.angular.Spin;
import jm.atom.SlaterLogCR;
import jm.atom.SlaterLogR;
import jm.atom.SlaterR;
import jm.atom.SystemOneElec;
import jm.atom.coulomb.CoulombFactory;
import jm.grid.*;
import jm.shell.FanoConfig;
import jm.shell.Shell;
import junit.framework.Test;
import junit.framework.TestSuite;
import stlx.duff_loop;
import stlx.valarrayx.valarray;

import javax.vecmathx.function.FunctionXY;
import javax.vecmathx.grid.StepGrid;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 3/04/2005, Time: 11:21:38
 */
public class ShiftedLogZetaHy extends ShiftedLogTestCase {
  public static Test suite() {
    return new TestSuite(ShiftedLogZetaHy.class);
  }
  public static void main(String[] args) {
    junit.textui.TestRunner.run(suite());
  }
  public void test_Hy_1S_LogCR() {
    WeightsLogCR w = new WeightsLogCR(x);
    LogCRToR xToR = w.getLogCRToR();
    valarray r = xToR;

    // WF
    double Zeff = 1;
    int L = 0;
    FunctionXY f = CoulombFactory.makeP1s(r, Zeff);
    f.setX(xToR.x); // MUST change grid for derivatives
    f.scale(xToR.getDivSqrtCR());
    double res = duff_loop.dot(f, f, w.withCR2());
    assertAndView("Hy norm(LogCR)=", res - 1, 6e-13);
    double test0 = -0.5;
    double testKin = -test0;
    double testPot = 2 * test0;
    LSCoupling LS = new LSCoupling(L, Spin.ELECTRON);
    Shell sh = new Shell(1, f, 1, LS.L, LS);
    FanoConfig fc = new FanoConfig(sh);
    SlaterLogCR slater = new SlaterLogCR(w);
    SystemOneElec sys = new SystemOneElec(-1., slater);
    double kin = sys.calcKin(fc, fc);
    assertAndView("Hy kin(LogCR)=", testKin - kin, 4e-11);
    double pot = sys.calcPot(fc, fc);
    assertAndView("Hy pot(LogCR)=", testPot - pot, 5e-12);
    assertAndView("Hy kin/pot(LogCR)=", -2. - pot / kin, 2e-10);
    res = sys.calcTot(fc, fc);
    assertAndView("Hy tot(LogCR)=", test0 - res, 3e-11);
  }
  public void test_Hy_1S_LogR() {
    WeightsLogR w = new WeightsLogR(x);
    LogRToR xToR = w.getLogRToR();
    valarray r = xToR;

    // WF
    double Z = 1;
    int L = 0;
    FunctionXY f = CoulombFactory.makeP1s(r, Z);
    f.setX(xToR.x); // MUST change grid for derivatives
    f.scale(xToR.getDivSqrtR());
    double res = duff_loop.dot(f, f, w.withR2());
    assertAndView("Hy norm(LogR)=", res - 1, 8e-6);
    double test0 = -0.5;
    double testKin = -test0;
    double testPot = 2 * test0;
    LSCoupling LS = new LSCoupling(L, Spin.ELECTRON);
    Shell sh = new Shell(1, f, 1, LS.L, LS);
    FanoConfig fc = new FanoConfig(sh);
    SlaterLogR slater = new SlaterLogR(w);
    SystemOneElec sys = new SystemOneElec(-Z, slater);
    double kin = sys.calcKin(fc, fc);
    assertAndView("Hy kin(LogR)=", testKin - kin, 7e-4);
    double pot = sys.calcPot(fc, fc);
    assertAndView("Hy pot(LogR)=", testPot - pot, 7e-4);
    assertAndView("Hy pot/kin(LogR)=", -2. - pot / kin, 2e-3);
    res = sys.calcTot(fc, fc);
    assertAndView("Hy tot(LogR)=", test0 - res, 4e-6);

    // With small R correction
    StepGrid smallR = new StepGrid(0, r.get(0), 9);
    f = CoulombFactory.makeP1s(smallR, Z);
    sh = new Shell(1, f, 1, LS.L, LS);
    fc = new FanoConfig(sh);
    WeightsR wR = new WeightsR(smallR);
    SlaterR slaterR = new SlaterR(wR);
    sys = new SystemOneElec(-Z, slaterR);
    kin += sys.calcKin(fc, fc);
    assertAndView("Hy kin(LogR+smallR)=", testKin - kin, 4e-11);
    pot += sys.calcPot(fc, fc);
    assertAndView("Hy pot(LogR+smallR)=", testPot - pot, 5e-12);
    assertAndView("Hy pot/kin(LogR+smallR)=", -2. - pot / kin, 2e-10);
    res += sys.calcTot(fc, fc);
    assertAndView("Hy tot(LogR+smallR)=", test0 - res, 4e-11);
  }
}
