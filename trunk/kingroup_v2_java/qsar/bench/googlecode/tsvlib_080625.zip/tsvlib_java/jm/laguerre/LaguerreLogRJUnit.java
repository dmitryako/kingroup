package jm.laguerre;
import jm.grid.LogRToR;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import stlx.duff_loop;

import javax.vecmathx.function.FunctionArray;
import javax.vecmathx.function.FunctionXY;
import javax.vecmathx.grid.StepGrid;
import javax.vecmathx.integration.BooleWeights;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 11/03/2005, Time: 16:44:51
 */
public class LaguerreLogRJUnit extends TestCase {
  private double eps_ = 1e-16;
  public static Test suite() {
    return new TestSuite(LaguerreLogRJUnit.class);
  }
  public static void main(String[] args) {
    junit.textui.TestRunner.run(suite());
  }
  public void testLaguerreArray() {
    double FIRST = 0;
    double LAST = 60;
    int GRID_SIZE = 201;
    FIRST = -5;
    LAST = 7; // exp(4.6)=99.5
    StepGrid x = new StepGrid(FIRST, LAST, GRID_SIZE);
    BooleWeights wx = new BooleWeights(x);
    LogRToR xToR = new LogRToR(x);
    FunctionXY xToR2 = xToR.getMapLogRToR2();
    LAST = Math.exp(FIRST); // e.g. FIRST = -5;
    int SMALL_R_SIZE = 5;
    StepGrid rS = new StepGrid(0, LAST, SMALL_R_SIZE); // small r
    BooleWeights wS = new BooleWeights(rS);
    int L = 0;
    int N = 4;
    int alpha = 2 * L + 2;
    double lambda = 0.7;
    FunctionArray arS = new LaguerreBasis(rS, N, alpha, lambda);
    FunctionArray arX = new LaguerreLogR(xToR, N, alpha, lambda);
    double resX = duff_loop.dot(arX.get(0), arX.get(0), wx, xToR2);
    double resS = duff_loop.dot(arS.get(0), arS.get(0), wS);
    assertEquals(0, Math.abs(resX - 1), 2e-8);//BETTER!
    assertEquals(0, Math.abs(resX + resS - 1), 3e-15);//BEST!!
    resX = duff_loop.dot(arX.get(0), arX.get(1), wx, xToR2);
    resS = duff_loop.dot(arS.get(0), arS.get(1), wS);
    assertEquals(0, Math.abs(resX), 4e-8);//BETTER!
    assertEquals(0, Math.abs(resX + resS), 2e-15);//BEST!
    resX = duff_loop.dot(arX.get(0), arX.get(2), wx, xToR2);
    resS = duff_loop.dot(arS.get(0), arS.get(2), wS);
    assertEquals(0, Math.abs(resX), 5e-8);//BETTER!
    assertEquals(0, Math.abs(resX + resS), 3e-14);//BEST!
    resX = duff_loop.dot(arX.get(1), arX.get(1), wx, xToR2);
    resS = duff_loop.dot(arS.get(1), arS.get(1), wS);
    assertEquals(0, Math.abs(resX - 1), 6e-8);//BETTER!
    assertEquals(0, Math.abs(resX + resS - 1), 4e-14);//BEST!
    resX = duff_loop.dot(arX.get(1), arX.get(2), wx, xToR2);
    resS = duff_loop.dot(arS.get(1), arS.get(2), wS);
    assertEquals(0, Math.abs(resX), 1e-7);//BETTER!
    assertEquals(0, Math.abs(resX + resS), 5e-13);//BEST!
  }
}
