package jm.atom;
import Jama.EigenvalueDecomposition;
import jm.angular.LSCoupling;
import jm.grid.LogRToR;
import jm.grid.WeightsLogCR;
import jm.grid.WeightsLogR;
import jm.grid.WeightsR;
import jm.laguerre.LaguerreLogCR;
import jm.laguerre.LaguerreLogR;
import jm.laguerre.LaguerreR;
import jm.shell.FanoArray;
import jm.shell.FanoFactory;

import javax.vecmathx.function.FunctionArray;
import javax.vecmathx.grid.StepGrid;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * See www.kingroup.org for more details.
 * User: jc138691, Date: Dec 10, 2004, Time: 7:29:48 AM
 */
public class HamiltonianFactory {
//   public static HamiltonianMatrix makeFromShiftedLegendra(int size
//                                        , int N, int L) {
//      StepGrid r = new StepGrid(0., 1., size);
//      BooleWeights w = new BooleWeights(r);
//      FunctionArray arr = new ShiftedLegendraOrthonorm(r, N);
//      FanoArray basisR = FanoFactory.makeOneElectronForY(N, L, arr);
//
//      // DOES NOT WORK!!!!
//      SlaterR SlaterR    SystemOneElec hydR = new SystemOneElec(-1., sr);
//      return new HamiltonianMatrix(basisR, hydR);
//   }
  public static HamiltonianMatrix makeFromLaguerreR(
    double first, double last, int size
    , int N, int L, int alpha, double lambda) {
    StepGrid r = new StepGrid(first, last, size);
    WeightsR w = new WeightsR(r);
    FunctionArray arr = new LaguerreR(r, N, alpha, lambda);
    FanoArray basisR = FanoFactory.makeOneElec(N, L, arr);
    Slater slater = new SlaterR(w);
    SystemOneElec hydR = new SystemOneElec(-1., slater);
    return new HamiltonianMatrix(basisR, hydR);
  }
  public static HamiltonianMatrix makeFromLaguerreLogR(
    double first, double last, int size
    , int N, int L, int alpha, double lambda) {
    StepGrid x = new StepGrid(first, last, size);
    LogRToR xToR = new LogRToR(x);
    WeightsLogR w = new WeightsLogR(x);
    FunctionArray arr = new LaguerreLogR(xToR, N, alpha, lambda);
    FanoArray basis = FanoFactory.makeOneElec(N, L, arr);
    Slater slater = new SlaterLogR(w);
    SystemOneElec hyd = new SystemOneElec(-1., slater);
    return new HamiltonianMatrix(basis, hyd);
  }
  public static HamiltonianMatrix makeHyFromLaguerreLogCR(
    double firstX, double last, int size
    , int N, int L, int alpha, double lambda) {
    StepGrid x = new StepGrid(firstX, last, size);
    // x=firstX -> r=0
    WeightsLogCR w = new WeightsLogCR(x);
    FunctionArray arr = new LaguerreLogCR(w.getLogCRToR(), N, alpha, lambda);
    FanoArray basis = FanoFactory.makeOneElec(N, L, arr);
    Slater slater = new SlaterLogCR(w);
    SystemOneElec hyd = new SystemOneElec(-1., slater);
    return new HamiltonianMatrix(basis, hyd);
  }
  public static HamiltonianMatrix makeHeFromLaguerreLogCR(StepGrid xToR
    , int N, int L, int alpha, double lambda, LSCoupling LS) {
    WeightsLogCR w = new WeightsLogCR(xToR);
    FunctionArray arr = new LaguerreLogCR(w.getLogCRToR(), N, alpha, lambda);
    FanoArray basis = FanoFactory.makeTwoElec(LS, N, L, arr);
    Slater slater = new SlaterLogCR(w);
    SystemOneElec hyd = new SystemOneElec(-1., slater);
    return new HamiltonianMatrix(basis, hyd);
  }
  public static EigenvalueDecomposition calcHeEnergies(StepGrid xToR
    , int N, int L, int alpha, double lambda, LSCoupling LS) {
    HamiltonianMatrix H = makeHeFromLaguerreLogCR(xToR, N, L, alpha, lambda, LS);
    return H.eig();
  }
}
