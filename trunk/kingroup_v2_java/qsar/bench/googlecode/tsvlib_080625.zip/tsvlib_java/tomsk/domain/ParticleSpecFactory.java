package tomsk.domain;
/**
 * Copyright: www.DmitryKonovalov.org, jc138691, 8/05/2007, 14:51:49
 */
public class ParticleSpecFactory
{
}
