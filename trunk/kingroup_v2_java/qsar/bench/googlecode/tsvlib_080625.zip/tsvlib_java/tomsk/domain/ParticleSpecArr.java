package tomsk.domain;
import java.util.ArrayList;

/**
 * Copyright: www.DmitryKonovalov.org, jc138691, 8/05/2007, 14:50:54
 */
public class ParticleSpecArr extends ArrayList<ParticleSpec>
{
  
}
