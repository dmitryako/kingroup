package tomsk.old.shannon;
import tomsk.view.j3dx.geometryx.Java3DBrownianGeometry;
/**
 * Created by IntelliJ IDEA.
 * User: Shannon
 * Date: Oct 25, 2004
 * Time: 11:05:30 AM
 * To change this template use File | Settings | File Templates.
 */
public class SpheresModel extends Java3DBrownianGeometry {
  public SpheresModel(int num) {
    super(num);
  }
}
