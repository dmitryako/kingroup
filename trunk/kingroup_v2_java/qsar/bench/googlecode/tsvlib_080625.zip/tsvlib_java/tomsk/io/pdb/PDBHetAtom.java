package tomsk.io.pdb;
/**
 * Copyright: www.DmitryKonovalov.org, jc138691, 8/05/2007, 17:08:22
 */
public class PDBHetAtom extends PDBAtom
{
  public static final String TYPE = "HETATM";
}
