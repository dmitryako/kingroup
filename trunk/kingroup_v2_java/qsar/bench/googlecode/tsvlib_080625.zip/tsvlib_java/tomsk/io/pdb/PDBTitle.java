package tomsk.io.pdb;
/**
 * Copyright: www.DmitryKonovalov.org, jc138691, 8/05/2007, 16:33:42
 */
public class PDBTitle extends PDBText
{
  public static final String TYPE = "TITLE";
  
  public PDBTitle(String text)
  {
    super(text);
  }
}
