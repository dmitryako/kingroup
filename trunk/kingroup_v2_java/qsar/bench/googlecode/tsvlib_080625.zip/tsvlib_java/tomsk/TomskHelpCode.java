package tomsk;
import tsvlib.project.ProjectLogger;

/**
 * Copyright: www.DmitryKonovalov.org, jc138691, 14/05/2007, 15:37:36
 */
public class TomskHelpCode
{
  private static ProjectLogger log = ProjectLogger.getLogger(TomskHelpCode.class);
}
