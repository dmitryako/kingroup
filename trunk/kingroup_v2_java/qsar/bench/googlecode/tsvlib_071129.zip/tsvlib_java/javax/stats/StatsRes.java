package javax.stats;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * See www.kingroup.org for more details.
 * User: jc138691, Date: Nov 18, 2004, Time: 9:09:59 AM
 */
public class StatsRes {
  private double mean;
  private double s2;
  private double[][] arr;
  private int[] idxArr;
  private double msep;
  private double mae;
  private double f;
  private double ra2;
  private double r2;
  private double msr;
  private double mst;

  public double getMean() {
    return mean;
  }
  public void setMean(double mean) {
    this.mean = mean;
  }
  public double getS() {
    return Math.sqrt(s2);
  }
  public double getS2()
  {
    return s2;
  }

  public void setS2(double s2)
  {
    this.s2 = s2;
  }
  public String toString() {
    return "mean=" + (float)mean + ", s=" + (float)getS() + ", s2=" + (float)getS2()
      + ", r2=" + (float)getR2()
      ;
  }

  public void setArr(double[][] arr)
  {
    this.arr = arr;
  }

  public double[][] getArr()
  {
    return arr;
  }

  public void setIdxArr(int[] idxArr)
  {
    this.idxArr = idxArr;
  }

  public int[] getIdxArr()
  {
    return idxArr;
  }

  public void setR2(double r2)
  {
    this.r2 = r2;
  }

  public double getR2()
  {
    return r2;
  }

  public void setMsep(double mse)
  {
    this.msep = mse;
  }

  public double getRmsep()
  {
    return Math.sqrt(msep);
  }
  public double getMsep()
  {
    return msep;
  }
  public void setMae(double mae)
  {
    this.mae = mae;
  }

  public double getMae()
  {
    return mae;
  }

  public void setF(double f)
  {
    this.f = f;
  }

  public double getF()
  {
    return f;
  }

  public void setRa2(double ra2)
  {
    this.ra2 = ra2;
  }

  public double getRa2()
  {
    return ra2;
  }

  public double getMsr()
  {
    return msr;
  }

  public void setMsr(double msr)
  {
    this.msr = msr;
  }

  public double getMst()
  {
    return mst;
  }

  public void setMst(double mst)
  {
    this.mst = mst;
  }

  public void add(StatsRes from)
  {
    mean += from.mean;
    msep += from.msep;
    msr += from.msr;
    mst += from.mst;
    mae += from.mae;
    f += from.f;
    ra2 += from.ra2;
    r2 += from.r2;
    s2 += from.s2;
  }

  public void norm(int n)
  {
    mean /= n;
    msep /= n;
    msr /= n;
    mst /= n;
    mae /= n;
    f /= n;
    ra2 /= n;
    r2 /= n;
    s2 /= n;
  }
}
