package javax.swingx.tablex;
import javax.swing.*;

/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 7/02/2006, Time: 09:11:59
 */
public interface JTableViewI
{
  public static String EMPTY = JTableFactory.EMPTY;
  public JTable getTableView();
}
