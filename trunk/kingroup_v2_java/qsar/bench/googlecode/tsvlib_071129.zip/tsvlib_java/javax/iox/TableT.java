package javax.iox;
/**
 * Copyright: www.DmitryKonovalov.org, jc138691, 29/03/2007, 17:42:14
 */
public class TableT<T> //TODO?
{
}
