package javax.utilx.pair;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 10/05/2006, Time: 09:54:21
 */
public class BytePair
{
  public byte a;
  public byte b;
  public BytePair(byte a, byte b) {
    this.a = a;
    this.b = b;
  }
//  public BytePair(BytePair from) {
//    this.a = from.a;
//    this.b = from.b;
//  }
  final public byte pair(byte v) {
    if (v == b)
      return a;
    if (v == a)
      return b;
    throw new RuntimeException("invalid input = " + v);
  }
  public String toString() {
    return "(" + a + ", " + b + ")";
  }
}
