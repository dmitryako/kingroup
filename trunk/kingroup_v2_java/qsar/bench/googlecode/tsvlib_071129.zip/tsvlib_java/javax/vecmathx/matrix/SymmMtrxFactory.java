package javax.vecmathx.matrix;

/**
 * Created by: jc1386591
 * Date: 16/06/2006. Time: 17:23:34
 */
public class SymmMtrxFactory {
/*  public double calcLowTriangleAvr(MtrxReadI m) {
    double sum = 0;
    for (int r = 0; r < m.size(); r++) {
      for (int c = 0; c < r; c++) {

      }
    }
  }
  */
}
