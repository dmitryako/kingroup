package javax.vecmathx.function;
import jm.JMatrixException;
import numeric.functor.Func1DI;
import stlx.valarrayx.valarray;

import javax.iox.LOG;
import javax.vecmathx.derivative.DerivFactory;

/* FunctionXY is a map of valarray to valarray
*/
public class FunctionXY extends valarray {
  public valarray x;
  private valarray drv; // first derivative
  public FunctionXY(final FunctionXY f) {
    super(f);
    x = f.x;
  }
  public FunctionXY(final valarray onX, int initSize) {
    super(initSize);
    this.x = onX;
  }
  public FunctionXY(final valarray x, final Func1DI f) {
    super(x);
    this.x = x;
    if (f != null)
      apply(f);
  }
  final public void setX(valarray g) {
    x = g;
  }
  // maximum absolute distance
  public double distSLOW(FunctionXY f) {
    double res = Math.abs(f.get(0) - get(0));
    for (int i = 1; i < size(); i++) {
      if (f.x.get(i) != x.get(i)) {
        String error = "different grid " + (float) x.get(i) + "!=" + (float) f.x.get(i);
        LOG.error(this, error, "");
        throw new JMatrixException(error);
      }
      double dist = Math.abs(f.get(i) - get(i));
      if (res < dist)
        res = dist;
    }
    return res;
  }
  final public valarray getDeriv() {
    if (drv == null)
      drv = DerivFactory.makeDeriv(this);
    return drv;
  }
}
