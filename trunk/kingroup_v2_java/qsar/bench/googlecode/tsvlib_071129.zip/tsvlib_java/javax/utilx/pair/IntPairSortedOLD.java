package javax.utilx.pair;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 26/06/2005, Time: 10:55:56
 */
public class IntPairSortedOLD {
  final public byte a;    // ordered: a<=b
  final public byte b;
  public IntPairSortedOLD(byte a, byte b) {
    if (a < b) {
      this.a = a;
      this.b = b;
    } else {
      this.a = b;
      this.b = a;
    }
  }

  public IntPairSortedOLD(BytePair pair)
  {
    this(pair.a, pair.b);
  }
}
