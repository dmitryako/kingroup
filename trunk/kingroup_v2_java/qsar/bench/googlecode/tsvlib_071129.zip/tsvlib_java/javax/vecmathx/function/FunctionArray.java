package javax.vecmathx.function;
import stlx.valarrayx.valarray;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * See www.kingroup.org for more details.
 * User: jc138691, Date: Dec 2, 2004, Time: 2:32:03 PM
 */
public class FunctionArray {
  private valarray x; // todo: make final
  private FunctionXY[] arr_;
  public FunctionArray(final valarray x, final int size) {
    this.x = x;
    init(size);
  }
  final public int size() {
    return arr_.length;
  }
  final public valarray grid() {
    return x;
  }
  final public void init(int size) {
    arr_ = new FunctionXY[size];
    for (int i = 0; i < arr_.length; i++) {
      arr_[i] = new FunctionXY(x, x.size());
    }
  }
  final public void setArray(FunctionXY[] arr) {
    arr_ = arr;
  }
  final public void set(int i, FunctionXY f) {
    arr_[i] = f;
  }
  final public FunctionXY[] getArray() {
    return arr_;
  }
  final public FunctionXY get(int i) {
    return arr_[i];
  }
  final public void changeGrid(valarray g) {
    x = g;
    for (int i = 0; i < arr_.length; i++) {
      arr_[i].setX(g);
    }
  }
  protected void safeDivide(valarray r) {
    for (int i = 0; i < arr_.length; i++) {
      arr_[i].safeDivide(r);
    }
  }
}
