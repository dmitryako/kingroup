package numeric.functor;
import netlib.math.complex.Complex;
public interface complex_functor {
  public Complex apply(Complex x);
}
