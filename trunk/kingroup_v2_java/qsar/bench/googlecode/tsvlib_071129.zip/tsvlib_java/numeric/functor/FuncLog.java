package numeric.functor;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * See www.kingroup.org for more details.
 * User: jc138691, Date: Dec 1, 2004, Time: 9:09:51 AM
 */
public class FuncLog implements Func1DI {
  public double calc(double x) {
    return Math.log(x);
  }
}
