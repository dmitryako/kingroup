package jm.atom;
import javax.vecmathx.function.FunctionXY;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 11/03/2005, Time: 08:28:07
 */
public class YkLogR { //template <class F>   class TYk : public F {
//   private static final double D1 = 1;
//   private static final double D4 = 4;
//   private static final double D30 = 30;
//   private static final int F_SIZE = 4;
//   private final double[] v = new double[F_SIZE + 1];
//   private final int MAX_I; // conversion from fortran/C++
//   private final int MAX_J;
//   private final double H;
//   private final double H3;
//   private final double EH;
//   private final FunctionXY f;//private const CFuncPowExp&    i_; // SHOULD only be used during the constructor invocation
//   private final FunctionXY f2;//private const CFuncPowExp&    j_;
//   private final int  K;
  public YkLogR(final FunctionXY f, final FunctionXY f2, final int K) { //TYk(const F& f, const F& f2, const CL& K)
//      super(f.x); //   : i_(f), j_(f2), k_(K), F(f.gridH()) {
//      this.K = K;
//      this.f = f;
//      this.f2 = f2;
//      MAX_I = f.size() - 1;
//      MAX_J = f2.size() - 1;
//      if (!(f.x instanceof StepGrid)) {
//         String mssg = "YkLogR can only work with StepGrid";
//         LOG.error(this, mssg, "");
//         throw new VecMathException(mssg);
//      }
//      H = ((StepGrid)f.x).step();
//      H3 = H / 3.0;
//      EH = Math.exp(-H);//EH = DEXP(-H)   // from SUBROUTINE INIT
//      //yk();
//      //set_ready();
  }
}

