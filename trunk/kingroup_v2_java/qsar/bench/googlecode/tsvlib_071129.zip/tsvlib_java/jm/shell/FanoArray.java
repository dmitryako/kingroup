package jm.shell;
import jm.JMatrixException;

import javax.iox.LOG;
import javax.iox.IOX;
import java.util.ArrayList;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * See www.kingroup.org for more details.
 * User: jc138691, Date: Dec 3, 2004, Time: 4:23:28 PM
 */
public class FanoArray extends ArrayList {
  public FanoArray() {
  }
  public FanoArray(FanoArray from) {
    if (from == null)
      return;
    for (int i = 0; i < from.size(); i++) {
      add(from.getConfig(i));
    }
  }
  public boolean add(Object obj) {
    String error = "use addLine(FanoConfig) instead";
    LOG.error(this, error, "");
    throw new JMatrixException(error);
  }
  public boolean add(FanoConfig fc) {
    if (find(fc))
      return false;
    return super.add(fc);
  }
  public boolean find(FanoConfig fc) {
    for (int i = 0; i < size(); i++) {
      FanoConfig fano = this.getConfig(i);
      if (fano.equals(fc))
        return true;
    }
    return false;
  }
  public FanoConfig getConfig(int i) {
    return (FanoConfig) get(i);
  }
  public String toString() {
    StringBuffer buff = new StringBuffer();
    for (int i = 0; i < size(); i++)
      buff.append(getConfig(i).toString()).append(IOX.eol);
    return buff.toString();
  }
}
