package jm.bspline;
import jm.grid.WeightsLogCR;
import stlx.valarrayx.valarray;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 25/04/2005, Time: 11:44:50
 */
public class BSplineFactory {
  public static BSplineLogCR makeBSplineLogCR(WeightsLogCR w, int basisSize, int k) {
    int knotsNum = BSplineBound.calcKnotsNumFromBasisSize(basisSize, k);
    valarray t = BSplineBound.makeBSplineKnotsFromGrid(knotsNum, w.getLogCRToR(), k);
    return new BSplineLogCR(w, t, k);
  }
}
