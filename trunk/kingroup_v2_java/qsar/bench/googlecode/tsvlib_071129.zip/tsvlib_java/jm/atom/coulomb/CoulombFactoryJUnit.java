package jm.atom.coulomb;
import jm.grid.LogCRToR;
import jm.grid.LogRToR;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import stlx.duff_loop;
import stlx.valarrayx.valarray;

import javax.vecmathx.function.FunctionXY;
import javax.vecmathx.grid.StepGrid;
import javax.vecmathx.integration.BooleWeights;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 14/03/2005, Time: 16:35:26
 */
public class CoulombFactoryJUnit extends TestCase {
  public static Test suite() {
    return new TestSuite(CoulombFactoryJUnit.class);
  }
  public static void main(String[] args) {
    junit.textui.TestRunner.run(suite());
  }
  public void testMakeP1s() {
    int NUM_STEPS = 220;
    double FIRST = -4;
    double STEP = 1. / 16.;
    StepGrid x = new StepGrid(FIRST, NUM_STEPS, STEP);
    LogCRToR logCR = new LogCRToR(x);
    LogRToR logR = new LogRToR(x);
    valarray r = logR;
    BooleWeights w = new BooleWeights(x);
    FunctionXY f = CoulombFactory.makeP1s(r, 1.);  // by log(r)
    double res = duff_loop.dot(f, f, w, r);
    assertEquals(0, Math.abs(res - 1), 1e-5);
    f = CoulombFactory.makeP1s(logCR, 1.); // by log(c+r)
//      LOG.saveToFile(valarray.asArray(x), valarray.asArray(f), "wf", "coulP1s.csv");
//      LOG.saveToFile(valarray.asArray(x), valarray.asArray(logCR), "wf", "logCR.csv");
//      LOG.saveToFile(valarray.asArray(x), valarray.asArray(logCR.getCR()), "wf", "y.csv");
    res = duff_loop.dot(f, f, w, logCR.getCR());
    assertEquals(0, Math.abs(res - 1), 6e-13);
    f = CoulombFactory.makeP1s(logCR, 2.);
    res = duff_loop.dot(f, f, w, logCR.getCR());
    assertEquals(0, Math.abs(res - 1), 4e-12);
    f = CoulombFactory.makeP1s(logR, 2.);
    res = duff_loop.dot(f, f, w, r);
    assertEquals(0, Math.abs(res - 1), 1e-4);
  }
  public void testMakeP2sp() {
    int NUM_STEPS = 220;
    double FIRST = -4;
    double STEP = 1. / 16.;
    StepGrid x = new StepGrid(FIRST, NUM_STEPS, STEP);
    LogCRToR logCR = new LogCRToR(x);
    valarray r = logCR;
    BooleWeights w = new BooleWeights(x);
    FunctionXY f = CoulombFactory.makeP2s(r, 1.); // by log(c+r)
    double res = duff_loop.dot(f, f, w, logCR.getCR());
    assertEquals(0, Math.abs(res - 1), 2e-13);
    FunctionXY f2 = CoulombFactory.makeP1s(r, 1.);
    res = duff_loop.dot(f, f2, w, logCR.getCR());
    assertEquals(0, Math.abs(res), 2e-13);
    f = CoulombFactory.makeP2s(r, 2.);
    res = duff_loop.dot(f, f, w, logCR.getCR());
    assertEquals(0, Math.abs(res - 1), 5e-13);
    f2 = CoulombFactory.makeP1s(r, 2.);
    res = duff_loop.dot(f, f2, w, logCR.getCR());
    assertEquals(0, Math.abs(res), 2e-12);
    f = CoulombFactory.makeP2p(r, 1.);      // 2p
    res = duff_loop.dot(f, f, w, logCR.getCR());
    assertEquals(0, Math.abs(res - 1), 7e-14);
    f = CoulombFactory.makeP2p(r, 2.);    // 2p
    res = duff_loop.dot(f, f, w, logCR.getCR());
    assertEquals(0, Math.abs(res - 1), 3e-14);
  }
  public void testMakeP3spd() {
    int NUM_STEPS = 220;
    double FIRST = -4;
    double STEP = 1. / 16.;
    StepGrid x = new StepGrid(FIRST, NUM_STEPS, STEP);
    LogCRToR logCR = new LogCRToR(x);
    valarray r = logCR;
    BooleWeights w = new BooleWeights(x);
    FunctionXY f = CoulombFactory.makeP3s(r, 1.); // by log(c+r)
    double res = duff_loop.dot(f, f, w, logCR.getCR());
    assertEquals(0, Math.abs(res - 1), 2e-11);
    FunctionXY f2 = CoulombFactory.makeP1s(r, 1.);
    res = duff_loop.dot(f, f2, w, logCR.getCR());
    assertEquals(0, Math.abs(res), 1e-13);
    f2 = CoulombFactory.makeP2s(r, 1.);
    res = duff_loop.dot(f, f2, w, logCR.getCR());
    assertEquals(0, Math.abs(res), 2e-12);
    f = CoulombFactory.makeP3s(r, 2.);
    res = duff_loop.dot(f, f, w, logCR.getCR());
    assertEquals(0, Math.abs(res - 1), 6e-12);
    f = CoulombFactory.makeP3p(r, 2.);
    res = duff_loop.dot(f, f, w, logCR.getCR());
    assertEquals(0, Math.abs(res - 1), 2e-12);
    f2 = CoulombFactory.makeP2p(r, 2.);
    res = duff_loop.dot(f, f2, w, logCR.getCR());
    assertEquals(0, Math.abs(res), 3e-13);
    f = CoulombFactory.makeP3d(r, 2.);
    res = duff_loop.dot(f, f, w, logCR.getCR());
    assertEquals(0, Math.abs(res - 1), 1e-13);
  }
}
