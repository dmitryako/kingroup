package jm.atom.junit;
import jm.atom.YkLogCR;
import jm.atom.coulomb.CoulombFactory;
import jm.grid.LogCRToR;
import jm.grid.WeightsLogCR;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import stlx.duff_loop;
import stlx.valarrayx.valarray;

import javax.iox.LOG;
import javax.vecmathx.function.FunctionXY;
import javax.vecmathx.grid.StepGrid;
import javax.vecmathx.integration.BooleWeights;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 14/03/2005, Time: 14:31:52
 */
public class YkLogCRJUnit extends TestCase {
  public static Test suite() {
    return new TestSuite(YkLogCRJUnit.class);
  }
  public static void main(String[] args) {
    junit.textui.TestRunner.run(suite());
  }
  public void testZ_1() {
    double FIRST = -4;
    int NUM_STEPS = 220;
    double STEP = 1. / 16.;
    StepGrid x = new StepGrid(FIRST, NUM_STEPS, STEP);
    LogCRToR xToR = new LogCRToR(x);
    valarray r = xToR;
    BooleWeights w = new BooleWeights(x);
    WeightsLogCR wCR = new WeightsLogCR(x);
    FunctionXY f = CoulombFactory.makeP1s(r, 1.);
    LOG.saveToFile(valarray.asArray(x), valarray.asArray(f), "wf", "P1s_test.csv");
    double res = duff_loop.dot(f, f, w, xToR.getCR());
    assertEquals(0, Math.abs(res - 1), 6e-13);
    f.scale(xToR.getDivSqrtCR());
    LOG.saveToFile(valarray.asArray(x), valarray.asArray(f), "wf", "P1s_sqrtCR.csv");
    res = duff_loop.dot(f, f, w, xToR.getCR2());
    assertEquals(0, Math.abs(res - 1), 5.5e-13);
    res = duff_loop.dot(f, f, wCR.withCR2());
    assertEquals(0, Math.abs(res - 1), 5.5e-13);
    FunctionXY T = CoulombFactory.makeZ_1_1s(r); // valid
    FunctionXY Z = new YkLogCR(xToR, f, f, 1).calcZk();
    LOG.saveToFile(valarray.asArray(x), valarray.asArray(T), "wf", "Z_1_1s_test.csv");
    LOG.saveToFile(valarray.asArray(x), valarray.asArray(Z), "wf", "Z_1_1s.csv");
    assertEquals(0, Math.abs(T.distSLOW(Z)), 6e-9);
  }
  public void testZkLogCR() {
    double FIRST = -4;
//      int NUM_STEPS = 440;
//      double STEP = 1./32.;
    int NUM_STEPS = 220;
    double STEP = 1. / 16.;
    StepGrid x = new StepGrid(FIRST, NUM_STEPS, STEP);
    LogCRToR xToR = new LogCRToR(x);
    valarray r = xToR;
    BooleWeights w = new BooleWeights(x);
    FunctionXY f = CoulombFactory.makeP1s(r, 1.);
    double res = duff_loop.dot(f, f, w, xToR.getCR());
    assertEquals(0, Math.abs(res - 1), 6e-13);
    f.scale(xToR.getDivSqrtCR());
    FunctionXY T = CoulombFactory.makeZ_0_1s(r); // valid
    FunctionXY Z = new YkLogCR(xToR, f, f, 0).calcZk();
    LOG.saveToFile(valarray.asArray(x), valarray.asArray(r), "wf", "logCR.csv");
    LOG.saveToFile(valarray.asArray(x), valarray.asArray(T), "wf", "Z_0_1s_test.csv");
    LOG.saveToFile(valarray.asArray(x), valarray.asArray(Z), "wf", "Z_0_1s.csv");
    assertEquals(0, Math.abs(T.distSLOW(Z)), 6e-9);
  }
  public void testYkLogCR() {
    double FIRST = -4;
    int NUM_STEPS = 220;
    double STEP = 1. / 16.;
    StepGrid x = new StepGrid(FIRST, NUM_STEPS, STEP);
    LogCRToR xToR = new LogCRToR(x);
    valarray r = xToR;
    BooleWeights w = new BooleWeights(x);

    // 1s
    FunctionXY f = CoulombFactory.makeP1s(r, 1.);
    f.scale(xToR.getDivSqrtCR());
    double res = duff_loop.dot(f, f, w, xToR.getCR2());
    assertEquals(0, Math.abs(res - 1), 2e-10);
    FunctionXY T = CoulombFactory.makeY_0_1s(r); // valid
    FunctionXY Y = new YkLogCR(xToR, f, f, 0).calcYk();
    LOG.saveToFile(valarray.asArray(x), valarray.asArray(r), "wf", "logCR.csv");
    LOG.saveToFile(valarray.asArray(x), valarray.asArray(T), "wf", "Y_0_1s_test.csv");
    LOG.saveToFile(valarray.asArray(x), valarray.asArray(Y), "wf", "Y_0_1s.csv");
    assertEquals(0, Math.abs(T.distSLOW(Y)), 2e-9);

    // 1s-2s
    FunctionXY f2 = CoulombFactory.makeP2s(r, 1.);
    LOG.saveToFile(valarray.asArray(x), valarray.asArray(f2), "wf", "P2s_test.csv");
    f2.scale(xToR.getDivSqrtCR());
    LOG.saveToFile(valarray.asArray(x), valarray.asArray(f2), "wf", "P2s_sqrtCR.csv");
    res = duff_loop.dot(f, f2, w, xToR.getCR2());
    assertEquals(0, Math.abs(res), 2e-13);
//      T = CoulombFactory.makeY_0_2s(r); // valid
    Y = new YkLogCR(xToR, f, f2, 0).calcYk();
//      LOG.saveToFile(valarray.asArray(x), valarray.asArray(T), "wf", "Y_0_2s_test.csv");
    LOG.saveToFile(valarray.asArray(x), valarray.asArray(Y), "wf", "Y_0_1s2s.csv");
//      assertEquals(0, Math.abs(T.distSLOW(Y)), 2e-8);

    // 2s
    f = CoulombFactory.makeP2s(r, 1.);
    res = duff_loop.dot(f, f, w, xToR.getCR());
    assertEquals(0, Math.abs(res - 1), 2e-13);
    f.scale(xToR.getDivSqrtCR());
    T = CoulombFactory.makeY_0_2s(r); // valid
    Y = new YkLogCR(xToR, f, f, 0).calcYk();
    LOG.saveToFile(valarray.asArray(x), valarray.asArray(T), "wf", "Y_0_2s_test.csv");
    LOG.saveToFile(valarray.asArray(x), valarray.asArray(Y), "wf", "Y_0_2s.csv");
    assertEquals(0, Math.abs(T.distSLOW(Y)), 2e-8);

    // 2p
    f = CoulombFactory.makeP2p(r, 1.);
    res = duff_loop.dot(f, f, w, xToR.getCR());
    assertEquals(0, Math.abs(res - 1), 7e-14);
    f.scale(xToR.getDivSqrtCR());
    T = CoulombFactory.makeY_0_2p(r); // valid
    Y = new YkLogCR(xToR, f, f, 0).calcYk();
    LOG.saveToFile(valarray.asArray(x), valarray.asArray(T), "wf", "Y_0_2p_test.csv");
    LOG.saveToFile(valarray.asArray(x), valarray.asArray(Y), "wf", "Y_0_2p.csv");
    assertEquals(0, Math.abs(T.distSLOW(Y)), 6e-9);
  }
  public void testY_2() {
    double FIRST = -4;
    int NUM_STEPS = 220;
    double STEP = 1. / 16.;
    StepGrid x = new StepGrid(FIRST, NUM_STEPS, STEP);
    LogCRToR xToR = new LogCRToR(x);
    valarray r = xToR;
    BooleWeights w = new BooleWeights(x);

    // 2p
    FunctionXY f = CoulombFactory.makeP2p(r, 1.);
    double res = duff_loop.dot(f, f, w, xToR.getCR());
    assertEquals(0, Math.abs(res - 1), 7e-14);
    f.scale(xToR.getDivSqrtCR());
    FunctionXY T = CoulombFactory.makeY_2_2p(r); // valid
    FunctionXY Y = new YkLogCR(xToR, f, f, 2).calcYk();
    LOG.saveToFile(valarray.asArray(x), valarray.asArray(T), "wf", "Y_2_2p_test.csv");
    LOG.saveToFile(valarray.asArray(x), valarray.asArray(Y), "wf", "Y_2_2p.csv");
    assertEquals(0, Math.abs(T.distSLOW(Y)), 5e-8);
  }
}