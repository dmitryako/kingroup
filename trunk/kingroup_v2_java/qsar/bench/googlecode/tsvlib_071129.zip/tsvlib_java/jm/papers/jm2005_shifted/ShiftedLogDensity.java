package jm.papers.jm2005_shifted;
import Jama.EigenvalueDecomposition;
import jm.angular.LSCoupling;
import jm.angular.Spin;
import jm.atom.HamiltonianMatrix;
import jm.atom.KinPotEnergy;
import jm.atom.SlaterLogCR;
import jm.atom.SystemTwoElec;
import jm.atom.coulomb.CoulombFactory;
import jm.grid.LogCRToR;
import jm.grid.WeightsLogCR;
import jm.laguerre.LaguerreLogCR;
import jm.shell.FanoArray;
import jm.shell.FanoFactory;
import jm.shell.FanoTwoElec;
import jm.shell.Shell;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import stlx.duff_loop;
import stlx.valarrayx.valarray;

import javax.iox.LOG;
import javax.utilx.arrays.vec.Vec;
import javax.vecmathx.function.FunctionArray;
import javax.vecmathx.function.FunctionXY;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 11/04/2005, Time: 12:51:56
 */
public class ShiftedLogDensity extends ShiftedLogTestCase {
  public static Test suite() {
    return new TestSuite(ShiftedLogDensity.class);
  }
  public static void main(String[] args) {
    junit.textui.TestRunner.run(suite());
  }
  public void testHeZeta() {
    LOG.setTrace(true);
    double Z = 2;
//      StepGrid x = new StepGrid(FIRST - Math.log(Z), NUM_STEPS, STEP);
    WeightsLogCR w = new WeightsLogCR(x);
    LogCRToR xToR = w.getLogCRToR();
    valarray r = xToR;

    // from p445 of Clementi Roetti, Atomic Data 14, 177 (1974)
    double Zeff = 1.6875;// from p445 of Clementi Roetti, Atomic Data 14, 177 (1974)
    FunctionXY f = CoulombFactory.makeP1s(r, Zeff);
    f.setX(xToR.x); // MUST change grid for derivatives
    f.scale(xToR.getDivSqrtCR());
    double res = duff_loop.dot(f, f, w.withCR2());
//      LOG.saveToFile(valarray.asArray(x), valarray.asArray(f), "wf", "He_zeta.csv");
    assertEquals(0, Math.abs(res - 1), 3e-14);
    FunctionXY zeta = new FunctionXY(f);
    zeta.scale(f);
    zeta.scale(xToR.getCR2());
    zeta.scale(2);
    LOG.saveToFile(valarray.asArray(x), valarray.asArray(zeta), "wf", "He_zeta.csv");
    LSCoupling LS = new LSCoupling(0, Spin.SINGLET);
    Shell sh = new Shell(1, f, 2, LS.L, LS);
    FanoTwoElec fc = new FanoTwoElec(sh);
    SlaterLogCR slater = new SlaterLogCR(w);
    SystemTwoElec sys = new SystemTwoElec(-Z, slater);
    res = sys.calcTot(fc, fc);
    assertEquals(0, Math.abs(-2.84765625 - res), 4e-12);
    FunctionXY conf = sys.calcConfigDensity(fc, fc);
    res = duff_loop.dot(conf, w);
    assertEquals(2, res, 3e-14);
//      conf.scale(xToR.getDivR());
//      conf.scale(xToR.getDivR());
    LOG.saveToFile(valarray.asArray(x), valarray.asArray(conf), "wf", "He_zeta_density.csv");
  }
  public void testEnergy() {
    double Z = 2;
    WeightsLogCR w = new WeightsLogCR(x);
    LogCRToR xToR = w.getLogCRToR();
    int sN = 10;
    int sAlpha = 2;
//      double sLambda = 2 * 1.6875;
    double sLambda = 4;
    int L = 0;
    LSCoupling LS = new LSCoupling(0, Spin.SINGLET);
    FunctionArray arr = new LaguerreLogCR(xToR, sN, sAlpha, sLambda);
    double res = w.calcMaxNormError(arr);
    TestCase.assertEquals(0, res, NORM_ERROR);
    SlaterLogCR slater = new SlaterLogCR(w);
    SystemTwoElec sys = new SystemTwoElec(-Z, slater);
    FanoArray currBasis = FanoFactory.makeTwoElecFrom(null, LS, sN, L, arr);
    int totN = currBasis.size();
    LOG.report(this, "totN=" + totN);
    HamiltonianMatrix H = new HamiltonianMatrix(currBasis, sys);
    EigenvalueDecomposition eig = H.eig();
    LOG.report(this, "H=" + Vec.toString(eig.getRealEigenvalues()));
    double E = eig.getRealEigenvalues()[0];
    LOG.report(this, "L=" + L + ", N=" + sN + ", E[0]=" + E);
    KinPotEnergy configE = H.calcEnergy(eig, 0);
    LOG.report(this, "config E=" + (configE.kin + configE.pot));
    TestCase.assertEquals(E, configE.kin + configE.pot, 1e-10);
    FunctionXY conf = H.calcDensity(eig, 0);
    res = duff_loop.dot(conf, w);
//      conf.scale(xToR.getDivR());
//      conf.scale(xToR.getDivR());
    LOG.saveToFile(valarray.asArray(x), valarray.asArray(conf), "wf"
      , "He_ground_density_" + sN + ".csv");
    assertEquals(2, res, 1e-10);
  }
}