package tsvlib.project;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * This code is licensed under the GPL license (see www.gnu.org) for academic,
 * not-for-profit use or for use within other Open Source software (see www.opensource.org).
 * See www.kingroup.org for more details.
 * User: jc138691
 * Date: Aug 20, 2004, Time: 4:08:48 PM
 */
public class ProjectModel {
  private String orgType;
  private String appName;
  private String appVersion;
  private String dirName;
  private String fileName;
  public void copyTo(ProjectModel bean) {
    bean.setOrgType(getOrgType());
    bean.setAppName(getAppName());
    bean.setAppVersion(getAppVersion());
    bean.setDirName(getDirName());
    bean.setFileName(getFileName());
  }
  final public void setOrgType(String v) {
    orgType = v;
  }
  final public String getOrgType() {
    return orgType;
  }
  final public void setAppName(String v) {
    appName = v;
  }
  final public String getAppName() {
    return appName;
  }
  final public void setAppVersion(String v) {
    appVersion = v;
  }
  final public String getAppVersion() {
    return appVersion;
  }
  final public void setFileName(String v) {
    fileName = v;
  }
  final public String getFileName() {
    return fileName;
  }
  final public void setDirName(String v) {
    dirName = v;
  }
  final public String getDirName() {
    return dirName;
  }
}
