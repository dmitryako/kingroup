package ledax;
/**
 * Copyright (C) 2004  KinGroup Development Team.
 * See www.kingroup.org for more details.
 * User: jc138691, Date: Nov 3, 2004, Time: 11:30:20 AM
 */
public class LEDAX {
  public static boolean leda_assert(boolean test) {
    return test;
  }
}
