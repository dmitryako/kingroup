package algorithm;
/**
 * Copyright KinGroup Team.
 * User: jc138691, Date: 7/04/2006, Time: 15:02:47
 */
public interface Func2DI
{
  public double calc(double x, double y);
}
