package pattern.ucm;
import javax.swingx.tablex.TableViewWithOpt;

/**
 * Copyright: www.DmitryKonovalov.org, jc138691, 24/04/2007, 10:48:38
 */
public interface UCUpdateTable extends UCController
{
  public void setUpdateView(TableViewWithOpt tableView);
}
