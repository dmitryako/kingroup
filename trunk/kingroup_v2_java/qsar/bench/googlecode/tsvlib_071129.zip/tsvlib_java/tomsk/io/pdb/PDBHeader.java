package tomsk.io.pdb;
/**
 * Copyright: www.DmitryKonovalov.org, jc138691, 8/05/2007, 16:21:30
 */
public class PDBHeader extends PDBText
{
  public static final String TYPE = "HEADER";

  public PDBHeader(String text)
  {
    super(text);
  }
}
